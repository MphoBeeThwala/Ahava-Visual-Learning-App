import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import {
  Crown,
  MapPin,
  Clock,
  Star,
  Check,
  Sparkles,
  Plane,
  Camera,
  Calendar,
  Gift,
} from "lucide-react";

const pricingTiers = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    description: "Perfect for students and casual explorers",
    features: ["All core experiences", "Standard quality", "Basic quizzes", "Community support"],
    highlighted: false,
    cta: "Get Started",
  },
  {
    name: "Explorer",
    price: "$9.99",
    period: "/month",
    description: "Enhanced experience for serious learners",
    features: ["All Free features", "Premium experiences", "4K quality", "Ad-free viewing", "Offline downloads"],
    highlighted: true,
    cta: "Start Free Trial",
  },
  {
    name: "Voyager",
    price: "$19.99",
    period: "/month",
    description: "The ultimate immersive learning journey",
    features: ["All Explorer features", "Live events access", "Expert-guided tours", "3D walkable scenes", "Priority support"],
    highlighted: false,
    cta: "Go Voyager",
  },
  {
    name: "School",
    price: "$500",
    period: "/year",
    description: "Complete classroom solution",
    features: ["All Voyager features", "Class management", "Analytics dashboard", "Curriculum tools", "No ads for all students"],
    highlighted: false,
    cta: "Contact Sales",
  },
];

export default function Tourism() {
  const { data: experiences } = trpc.experience.list.useQuery({ category: "nature", limit: 50 });
  const premiumExps = (experiences ?? []).filter((e: any) => e.isPremium).slice(0, 4);

  return (
    <div className="min-h-full">
      {/* Hero */}
      <div className="relative h-[300px] overflow-hidden">
        <img src="/experiences/northern-lights.jpg" alt="Hero" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#181A20] via-[#181A20]/70 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#181A20] via-transparent to-transparent" />
        <div className="relative z-10 flex flex-col justify-center h-full px-6 lg:px-10">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#F59E0B]/20 border border-[#F59E0B]/30 w-fit mb-4">
            <Crown className="w-3.5 h-3.5 text-[#F59E0B]" />
            <span className="text-xs font-medium text-[#F59E0B]">Premium Experiences</span>
          </div>
          <h1 className="text-3xl lg:text-4xl font-bold text-[#F4F6F8]">
            Explore Before You Go.<br />
            <span className="text-[#F59E0B]">Travel Deeper.</span>
          </h1>
          <p className="mt-3 text-base text-[#8E92A4] max-w-lg">
            Premium immersive experiences for travelers. Preview destinations, plan trips, and learn about the world's most extraordinary places.
          </p>
        </div>
      </div>

      <div className="px-4 lg:px-6 py-6">
        {/* Premium Experiences */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-[#F4F6F8] mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#F59E0B]" /> Premium Experiences
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {premiumExps.length > 0 ? (
              premiumExps.map((exp: any) => (
                <Link
                  key={exp.id}
                  to={`/experience/${exp.slug}`}
                  className="group bg-[#23262F] rounded-xl border border-[#2C2F3A] overflow-hidden hover:border-[#F59E0B]/50 transition-all duration-300"
                >
                  <div className="aspect-video overflow-hidden relative">
                    <img src={exp.thumbnailUrl} alt={exp.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    <div className="absolute top-2 right-2">
                      <span className="px-2 py-0.5 rounded-md bg-[#F59E0B] text-[#181A20] text-[10px] font-bold uppercase">Premium</span>
                    </div>
                  </div>
                  <div className="p-3">
                    <h3 className="text-sm font-semibold text-[#F4F6F8] group-hover:text-[#F59E0B] transition-colors">{exp.title}</h3>
                    <div className="flex items-center gap-2 mt-1 text-xs text-[#8E92A4]">
                      <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{exp.country}</span>
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{Math.floor(exp.durationSeconds / 60)}m</span>
                      <span className="flex items-center gap-1"><Star className="w-3 h-3 text-[#F59E0B]" />{exp.avgRating}</span>
                    </div>
                  </div>
                </Link>
              ))
            ) : (
              [1, 2, 3, 4].map((i) => (
                <div key={i} className="bg-[#23262F] rounded-xl border border-[#2C2F3A] overflow-hidden">
                  <div className="aspect-video bg-[#2C2F3A] animate-pulse" />
                  <div className="p-3 space-y-2">
                    <div className="h-4 bg-[#2C2F3A] rounded animate-pulse w-3/4" />
                    <div className="h-3 bg-[#2C2F3A] rounded animate-pulse w-1/2" />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          {[
            { icon: Plane, title: "Trip Planner", desc: "Build custom itineraries with experiences", color: "#3B82F6" },
            { icon: Camera, title: "4K Quality", desc: "Crystal-clear immersive content", color: "#10B981" },
            { icon: Calendar, title: "Live Events", desc: "Join live-streamed expeditions", color: "#F59E0B" },
          ].map((feat) => (
            <div key={feat.title} className="bg-[#23262F] rounded-xl border border-[#2C2F3A] p-5 flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0" style={{ backgroundColor: feat.color + "20" }}>
                <feat.icon className="w-5 h-5" style={{ color: feat.color }} />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-[#F4F6F8]">{feat.title}</h3>
                <p className="text-xs text-[#8E92A4] mt-1">{feat.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Pricing */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-[#F4F6F8] mb-4 text-center">Choose Your Plan</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {pricingTiers.map((tier) => (
              <div
                key={tier.name}
                className={`rounded-xl border p-5 transition-all ${
                  tier.highlighted
                    ? "bg-[#23262F] border-[#F59E0B]/50 ring-1 ring-[#F59E0B]/20"
                    : "bg-[#23262F] border-[#2C2F3A]"
                }`}
              >
                {tier.highlighted && (
                  <span className="inline-block px-2 py-0.5 rounded-md bg-[#F59E0B]/15 text-[#F59E0B] text-[10px] font-bold uppercase tracking-wider mb-3">
                    Most Popular
                  </span>
                )}
                <h3 className="text-lg font-semibold text-[#F4F6F8]">{tier.name}</h3>
                <div className="flex items-baseline gap-1 mt-2">
                  <span className="text-3xl font-bold text-[#F4F6F8] font-display">{tier.price}</span>
                  <span className="text-xs text-[#8E92A4]">{tier.period}</span>
                </div>
                <p className="text-xs text-[#8E92A4] mt-2">{tier.description}</p>
                <ul className="mt-4 space-y-2">
                  {tier.features.map((feat) => (
                    <li key={feat} className="flex items-center gap-2 text-xs text-[#8E92A4]">
                      <Check className="w-3.5 h-3.5 text-[#10B981] shrink-0" /> {feat}
                    </li>
                  ))}
                </ul>
                <button
                  className={`w-full mt-5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    tier.highlighted
                      ? "bg-[#F59E0B] text-[#181A20] hover:bg-[#D97706]"
                      : "bg-[#181A20] border border-[#2C2F3A] text-[#F4F6F8] hover:bg-[#2C2F3A]"
                  }`}
                >
                  {tier.cta}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Gift */}
        <div className="bg-gradient-to-r from-[#8B5CF6]/20 via-[#3B82F6]/20 to-[#10B981]/20 rounded-xl border border-[#8B5CF6]/30 p-6 text-center">
          <Gift className="w-8 h-8 text-[#8B5CF6] mx-auto mb-3" />
          <h3 className="text-lg font-semibold text-[#F4F6F8]">Gift a Subscription</h3>
          <p className="text-sm text-[#8E92A4] mt-1 max-w-md mx-auto">
            Share the gift of learning. Purchase a subscription for a school, student, or loved one.
          </p>
          <button className="mt-4 px-6 py-2.5 rounded-xl bg-[#8B5CF6] text-white text-sm font-medium hover:bg-[#7C3AED] transition-all">
            Gift TerraLearn
          </button>
        </div>
      </div>
    </div>
  );
}
