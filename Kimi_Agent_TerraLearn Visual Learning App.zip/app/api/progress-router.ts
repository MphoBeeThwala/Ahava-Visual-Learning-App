import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";

export const progressRouter = createRouter({
  upsert: authedQuery
    .input(
      z.object({
        experienceId: z.number(),
        completionPercentage: z.number().optional(),
        timeSpentSeconds: z.number().optional(),
        quizScore: z.number().optional(),
        lastPositionYaw: z.number().optional(),
        lastPositionPitch: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return { success: true, data: input };
    }),

  list: authedQuery.query(async () => {
    return [
      { experienceId: 1, completionPercentage: 100, timeSpentSeconds: 1200, quizScore: 90, completedAt: new Date("2024-05-01"), title: "Serengeti Great Migration", thumbnailUrl: "/experiences/serengeti.jpg" },
      { experienceId: 3, completionPercentage: 75, timeSpentSeconds: 900, quizScore: null, completedAt: null, title: "Great Barrier Reef Dive", thumbnailUrl: "/experiences/great-barrier-reef.jpg" },
      { experienceId: 4, completionPercentage: 100, timeSpentSeconds: 1400, quizScore: 85, completedAt: new Date("2024-05-10"), title: "Machu Picchu: Lost City", thumbnailUrl: "/experiences/machu-picchu.jpg" },
      { experienceId: 10, completionPercentage: 30, timeSpentSeconds: 400, quizScore: null, completedAt: null, title: "Yellowstone Geysers", thumbnailUrl: "/experiences/yellowstone.jpg" },
    ];
  }),

  stats: authedQuery.query(async () => {
    return {
      totalCompleted: 2,
      totalInProgress: 2,
      totalTimeSpent: 3900,
      avgScore: 87.5,
      streakDays: 7,
      experiencesExplored: 4,
      totalExperiences: 21,
    };
  }),
});
