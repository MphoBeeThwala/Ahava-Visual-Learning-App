import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  boolean,
  decimal,
  json,
  bigint,
} from "drizzle-orm/mysql-core";

// ─── Users ───
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "teacher", "student", "admin"]).default("user").notNull(),
  gradeLevel: int("gradeLevel"),
  schoolName: varchar("schoolName", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Experiences ───
export const experiences = mysqlTable("experiences", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  description: text("description").notNull(),
  category: mysqlEnum("category", ["nature", "history", "stem", "culture", "conservation"]).notNull(),
  subcategory: varchar("subcategory", { length: 100 }).notNull(),
  stemType: mysqlEnum("stemType", ["biology", "chemistry", "physics", "none"]).default("none").notNull(),
  gradeLevelMin: int("gradeLevelMin").notNull(),
  gradeLevelMax: int("gradeLevelMax").notNull(),
  durationSeconds: int("durationSeconds").notNull(),
  locationLat: decimal("locationLat", { precision: 10, scale: 8 }),
  locationLng: decimal("locationLng", { precision: 11, scale: 8 }),
  country: varchar("country", { length: 100 }),
  region: varchar("region", { length: 100 }),
  isPremium: boolean("isPremium").default(false).notNull(),
  isPublished: boolean("isPublished").default(true).notNull(),
  panoramaUrl: text("panoramaUrl"),
  thumbnailUrl: text("thumbnailUrl").notNull(),
  learningOutcomes: json("learningOutcomes").$type<string[]>(),
  curriculumTags: json("curriculumTags").$type<string[]>(),
  accessibilityFeatures: json("accessibilityFeatures").$type<string[]>(),
  avgRating: decimal("avgRating", { precision: 2, scale: 1 }).default("4.5").notNull(),
  reviewCount: int("reviewCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type Experience = typeof experiences.$inferSelect;
export type InsertExperience = typeof experiences.$inferInsert;

// ─── Hotspots ───
export const hotspots = mysqlTable("hotspots", {
  id: serial("id").primaryKey(),
  experienceId: bigint("experienceId", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  yaw: decimal("yaw", { precision: 6, scale: 2 }).notNull(),
  pitch: decimal("pitch", { precision: 6, scale: 2 }).notNull(),
  iconType: mysqlEnum("iconType", ["info", "quiz", "media", "molecule", "organ", "physics"]).default("info").notNull(),
  relatedExperienceId: bigint("relatedExperienceId", { mode: "number", unsigned: true }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Hotspot = typeof hotspots.$inferSelect;

// ─── Quizzes ───
export const quizzes = mysqlTable("quizzes", {
  id: serial("id").primaryKey(),
  experienceId: bigint("experienceId", { mode: "number", unsigned: true }).notNull(),
  question: text("question").notNull(),
  options: json("options").$type<string[]>().notNull(),
  correctAnswerIndex: int("correctAnswerIndex").notNull(),
  explanation: text("explanation"),
  points: int("points").default(10).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Quiz = typeof quizzes.$inferSelect;

// ─── Classes ───
export const classes = mysqlTable("classes", {
  id: serial("id").primaryKey(),
  teacherId: bigint("teacherId", { mode: "number", unsigned: true }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  gradeLevel: int("gradeLevel").notNull(),
  subject: varchar("subject", { length: 100 }).notNull(),
  inviteCode: varchar("inviteCode", { length: 20 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Class = typeof classes.$inferSelect;

// ─── Class Students ───
export const classStudents = mysqlTable("class_students", {
  id: serial("id").primaryKey(),
  classId: bigint("classId", { mode: "number", unsigned: true }).notNull(),
  studentId: bigint("studentId", { mode: "number", unsigned: true }).notNull(),
  joinedAt: timestamp("joinedAt").defaultNow().notNull(),
});

// ─── Assignments ───
export const assignments = mysqlTable("assignments", {
  id: serial("id").primaryKey(),
  classId: bigint("classId", { mode: "number", unsigned: true }).notNull(),
  experienceId: bigint("experienceId", { mode: "number", unsigned: true }).notNull(),
  assignedAt: timestamp("assignedAt").defaultNow().notNull(),
  dueDate: timestamp("dueDate"),
  quizRequired: boolean("quizRequired").default(false).notNull(),
  notes: text("notes"),
});

// ─── Student Progress ───
export const studentProgress = mysqlTable("student_progress", {
  id: serial("id").primaryKey(),
  studentId: bigint("studentId", { mode: "number", unsigned: true }).notNull(),
  experienceId: bigint("experienceId", { mode: "number", unsigned: true }).notNull(),
  completionPercentage: int("completionPercentage").default(0).notNull(),
  timeSpentSeconds: int("timeSpentSeconds").default(0).notNull(),
  quizScore: int("quizScore"),
  completedAt: timestamp("completedAt"),
  lastPositionYaw: decimal("lastPositionYaw", { precision: 6, scale: 2 }),
  lastPositionPitch: decimal("lastPositionPitch", { precision: 6, scale: 2 }),
  bookmarks: json("bookmarks").$type<number[]>(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

// ─── Reviews ───
export const reviews = mysqlTable("reviews", {
  id: serial("id").primaryKey(),
  experienceId: bigint("experienceId", { mode: "number", unsigned: true }).notNull(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  rating: int("rating").notNull(),
  text: text("text"),
  isTeacher: boolean("isTeacher").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
