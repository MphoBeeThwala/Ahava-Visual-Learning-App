import { useParams, useNavigate } from "react-router";
import { useEffect, useRef, useState, useCallback } from "react";
import * as THREE from "three";
import { trpc } from "@/providers/trpc";
import {
  ChevronLeft,
  Maximize2,
  Settings,
  Play,
  Pause,
  Volume2,
  MapPin,
  Info,
  X,
} from "lucide-react";

export default function Viewer360() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const animRef = useRef<number>(0);

  const [uiVisible, setUiVisible] = useState(true);
  const [isPlaying, setIsPlaying] = useState(true);
  const [activeHotspot, setActiveHotspot] = useState<any>(null);
  const [progress] = useState(0);

  const { data: exp } = trpc.experience.getBySlug.useQuery({ slug: slug! });
  const { data: hotspots } = trpc.hotspot.listByExperience.useQuery(
    { experienceId: exp?.id ?? 0 },
    { enabled: !!exp?.id }
  );

  // Mouse/touch state for camera rotation
  const mouseRef = useRef({ isDown: false, lastX: 0, lastY: 0, theta: 0, phi: Math.PI / 2 });
  const targetRef = useRef({ theta: 0, phi: Math.PI / 2 });

  const initScene = useCallback(() => {
    const container = containerRef.current;
    if (!container || rendererRef.current) return;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(70, container.offsetWidth / container.offsetHeight, 0.1, 1000);
    camera.position.set(0, 0, 0.00001);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setSize(container.offsetWidth, container.offsetHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.domElement.style.width = "100%";
    renderer.domElement.style.height = "100%";
    renderer.domElement.style.display = "block";
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Create sphere with equirectangular texture
    const geometry = new THREE.SphereGeometry(500, 60, 40);
    geometry.scale(-1, 1, 1);

    const textureLoader = new THREE.TextureLoader();
    textureLoader.crossOrigin = "anonymous";

    const textureUrl = exp?.thumbnailUrl || "/experiences/grand-canyon.jpg";
    textureLoader.load(textureUrl, (texture) => {
      texture.colorSpace = THREE.SRGBColorSpace;
      const material = new THREE.MeshBasicMaterial({ map: texture });
      const mesh = new THREE.Mesh(geometry, material);
      scene.add(mesh);
    }, undefined, () => {
      // Fallback: colored sphere
      const material = new THREE.MeshBasicMaterial({
        color: new THREE.Color().setHSL(0.6, 0.3, 0.15),
        wireframe: false,
      });
      const mesh = new THREE.Mesh(geometry, material);
      scene.add(mesh);
    });

    // Add hotspot markers
    if (hotspots) {
      hotspots.forEach((hs: any) => {
        const yawRad = (parseFloat(hs.yaw) * Math.PI) / 180;
        const pitchRad = (parseFloat(hs.pitch) * Math.PI) / 180;
        const r = 480;
        const x = r * Math.cos(pitchRad) * Math.sin(yawRad);
        const y = r * Math.sin(pitchRad);
        const z = r * Math.cos(pitchRad) * Math.cos(yawRad);

        const dotGeo = new THREE.SphereGeometry(3, 16, 16);
        const dotMat = new THREE.MeshBasicMaterial({
          color: hs.iconType === "quiz" ? 0xF59E0B : 0x3B82F6,
          transparent: true,
          opacity: 0.9,
        });
        const dot = new THREE.Mesh(dotGeo, dotMat);
        dot.position.set(x, y, z);
        dot.userData = { hotspot: hs };
        scene.add(dot);

        // Glow ring
        const ringGeo = new THREE.RingGeometry(4, 6, 32);
        const ringMat = new THREE.MeshBasicMaterial({
          color: hs.iconType === "quiz" ? 0xF59E0B : 0x3B82F6,
          transparent: true,
          opacity: 0.4,
          side: THREE.DoubleSide,
        });
        const ring = new THREE.Mesh(ringGeo, ringMat);
        ring.position.set(x, y, z);
        ring.lookAt(0, 0, 0);
        scene.add(ring);
      });
    }

    const animate = () => {
      animRef.current = requestAnimationFrame(animate);

      // Smooth camera damping
      const damping = 0.1;
      mouseRef.current.theta += (targetRef.current.theta - mouseRef.current.theta) * damping;
      mouseRef.current.phi += (targetRef.current.phi - mouseRef.current.phi) * damping;

      const r = 500;
      const cx = r * Math.sin(mouseRef.current.phi) * Math.cos(mouseRef.current.theta);
      const cy = r * Math.cos(mouseRef.current.phi);
      const cz = r * Math.sin(mouseRef.current.phi) * Math.sin(mouseRef.current.theta);
      camera.lookAt(cx, cy, cz);

      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      camera.aspect = container.offsetWidth / container.offsetHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.offsetWidth, container.offsetHeight);
    };
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, [exp, hotspots]);

  useEffect(() => {
    if (!exp) return;
    const cleanup = initScene();
    return () => {
      cancelAnimationFrame(animRef.current);
      if (rendererRef.current) {
        rendererRef.current.dispose();
        if (containerRef.current && rendererRef.current.domElement.parentNode) {
          containerRef.current.removeChild(rendererRef.current.domElement);
        }
        rendererRef.current = null;
      }
      cleanup?.();
    };
  }, [exp, initScene]);

  // Mouse/touch handlers
  const handlePointerDown = (e: React.PointerEvent) => {
    mouseRef.current.isDown = true;
    mouseRef.current.lastX = e.clientX;
    mouseRef.current.lastY = e.clientY;
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!mouseRef.current.isDown) return;
    const deltaX = e.clientX - mouseRef.current.lastX;
    const deltaY = e.clientY - mouseRef.current.lastY;
    mouseRef.current.lastX = e.clientX;
    mouseRef.current.lastY = e.clientY;

    targetRef.current.theta -= deltaX * 0.003;
    targetRef.current.phi -= deltaY * 0.003;
    targetRef.current.phi = Math.max(0.1, Math.min(Math.PI - 0.1, targetRef.current.phi));
  };

  const handlePointerUp = () => {
    mouseRef.current.isDown = false;
  };

  // Auto-hide UI
  useEffect(() => {
    const timer = setTimeout(() => setUiVisible(false), 4000);
    const showUi = () => {
      setUiVisible(true);
      clearTimeout(timer);
      setTimeout(() => setUiVisible(false), 4000);
    };
    window.addEventListener("pointermove", showUi);
    return () => {
      clearTimeout(timer);
      window.removeEventListener("pointermove", showUi);
    };
  }, []);

  return (
    <div className="fixed inset-0 bg-black z-50">
      {/* Three.js Canvas Container */}
      <div
        ref={containerRef}
        className="absolute inset-0 cursor-grab active:cursor-grabbing"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
      />

      {/* Loading overlay */}
      {!exp && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#181A20] z-20">
          <div className="text-center">
            <div className="animate-spin w-10 h-10 border-2 border-[#3B82F6] border-t-transparent rounded-full mx-auto mb-4" />
            <p className="text-sm text-[#8E92A4]">Loading immersive experience...</p>
          </div>
        </div>
      )}

      {/* Top UI Bar */}
      <div className={`absolute top-0 left-0 right-0 p-4 transition-opacity duration-300 ${uiVisible ? "opacity-100" : "opacity-0 pointer-events-none"}`}>
        <div className="liquid-glass rounded-xl px-4 py-3 flex items-center justify-between">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-[#F4F6F8] text-sm hover:text-[#3B82F6] transition-colors"
          >
            <ChevronLeft className="w-4 h-4" /> Exit
          </button>
          <div className="text-center">
            <h2 className="text-sm font-medium text-[#F4F6F8]">{exp?.title}</h2>
            <p className="text-[10px] text-[#8E92A4]">{exp?.country}</p>
          </div>
          <div className="flex items-center gap-2">
            <button className="p-2 rounded-lg text-[#8E92A4] hover:text-[#F4F6F8] hover:bg-white/10 transition-all">
              <Settings className="w-4 h-4" />
            </button>
            <button className="p-2 rounded-lg text-[#8E92A4] hover:text-[#F4F6F8] hover:bg-white/10 transition-all">
              <Maximize2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Bottom UI Bar */}
      <div className={`absolute bottom-0 left-0 right-0 p-4 transition-opacity duration-300 ${uiVisible ? "opacity-100" : "opacity-0 pointer-events-none"}`}>
        <div className="liquid-glass rounded-xl px-4 py-3">
          {/* Progress bar */}
          <div className="w-full h-1 bg-white/10 rounded-full mb-3 overflow-hidden">
            <div className="h-full bg-gradient-to-r from-[#3B82F6] to-[#10B981] rounded-full transition-all" style={{ width: `${progress}%` }} />
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="w-9 h-9 rounded-full bg-[#3B82F6] flex items-center justify-center hover:bg-[#2563EB] transition-all"
              >
                {isPlaying ? <Pause className="w-4 h-4 text-white" /> : <Play className="w-4 h-4 text-white ml-0.5" />}
              </button>
              <button className="p-2 rounded-lg text-[#8E92A4] hover:text-[#F4F6F8] hover:bg-white/10 transition-all">
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
            <div className="flex items-center gap-1 text-xs text-[#8E92A4]">
              <MapPin className="w-3 h-3" />
              {hotspots?.length ?? 0} hotspots
            </div>
          </div>
        </div>
      </div>

      {/* Hotspot Info Panel */}
      {activeHotspot && (
        <div className="absolute top-1/2 right-4 -translate-y-1/2 w-[320px] liquid-glass rounded-xl p-5 animate-fade-in-up">
          <button
            onClick={() => setActiveHotspot(null)}
            className="absolute top-3 right-3 text-[#8E92A4] hover:text-[#F4F6F8]"
          >
            <X className="w-4 h-4" />
          </button>
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${
            activeHotspot.iconType === "quiz" ? "bg-[#F59E0B]/15" : "bg-[#3B82F6]/15"
          }`}>
            <Info className={`w-5 h-5 ${activeHotspot.iconType === "quiz" ? "text-[#F59E0B]" : "text-[#3B82F6]"}`} />
          </div>
          <h3 className="text-lg font-semibold text-[#F4F6F8]">{activeHotspot.title}</h3>
          <p className="text-sm text-[#8E92A4] mt-2">{activeHotspot.description}</p>
        </div>
      )}
    </div>
  );
}
