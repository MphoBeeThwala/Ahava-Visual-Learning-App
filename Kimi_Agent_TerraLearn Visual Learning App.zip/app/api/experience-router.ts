import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { experiences, hotspots, quizzes } from "@db/schema";
import { eq } from "drizzle-orm";

// Comprehensive mock data for reliable responses
const mockExperiences = [
  { id: 1, title: "Serengeti Great Migration", slug: "serengeti-great-migration", description: "Witness one of nature's most spectacular events — the annual migration of over 1.5 million wildebeest, zebras, and gazelles across the Serengeti plains.", category: "nature", subcategory: "Wildlife", stemType: "biology", gradeLevelMin: 4, gradeLevelMax: 12, durationSeconds: 1200, locationLat: "-2.1540", locationLng: "34.6857", country: "Tanzania", region: "East Africa", isPremium: false, isPublished: true, thumbnailUrl: "/experiences/serengeti.jpg", learningOutcomes: ["Understand seasonal migration patterns","Identify keystone species","Analyze predator-prey dynamics"], curriculumTags: ["Biology","Ecology","Geography"], accessibilityFeatures: ["Captions","Audio Description"], avgRating: "4.8", reviewCount: 245, createdAt: new Date("2024-01-15"), updatedAt: new Date("2024-01-15") },
  { id: 2, title: "The Grand Canyon Layers", slug: "grand-canyon-layers", description: "Descend through 2 billion years of Earth's history in the Grand Canyon. Each rock layer tells a story of ancient oceans, deserts, and mountains.", category: "nature", subcategory: "Geology", stemType: "physics", gradeLevelMin: 6, gradeLevelMax: 12, durationSeconds: 1500, locationLat: "36.1069", locationLng: "-112.1129", country: "United States", region: "North America", isPremium: false, isPublished: true, thumbnailUrl: "/experiences/grand-canyon.jpg", learningOutcomes: ["Interpret geological time scales","Identify sedimentary rock formations","Explain erosion processes"], curriculumTags: ["Geology","Earth Science"], accessibilityFeatures: ["Captions"], avgRating: "4.7", reviewCount: 189, createdAt: new Date("2024-01-20"), updatedAt: new Date("2024-01-20") },
  { id: 3, title: "Great Barrier Reef Dive", slug: "great-barrier-reef-dive", description: "Dive into the world's largest coral reef system. Explore vibrant coral gardens, encounter diverse marine species, and understand reef ecosystems.", category: "nature", subcategory: "Marine", stemType: "biology", gradeLevelMin: 5, gradeLevelMax: 12, durationSeconds: 1800, locationLat: "-18.2871", locationLng: "147.6992", country: "Australia", region: "Oceania", isPremium: true, isPublished: true, thumbnailUrl: "/experiences/great-barrier-reef.jpg", learningOutcomes: ["Describe coral polyp anatomy","Identify reef fish species","Explain coral bleaching"], curriculumTags: ["Marine Biology","Ecology"], accessibilityFeatures: ["Captions","Audio Description"], avgRating: "4.9", reviewCount: 312, createdAt: new Date("2024-02-01"), updatedAt: new Date("2024-02-01") },
  { id: 4, title: "Machu Picchu: Lost City", slug: "machu-picchu-lost-city", description: "Explore the ancient Inca citadel perched high in the Andes Mountains. Discover engineering marvels and astronomical alignments.", category: "history", subcategory: "Ancient Civilizations", stemType: "none", gradeLevelMin: 5, gradeLevelMax: 12, durationSeconds: 1400, locationLat: "-13.1631", locationLng: "-72.5450", country: "Peru", region: "South America", isPremium: false, isPublished: true, thumbnailUrl: "/experiences/machu-picchu.jpg", learningOutcomes: ["Analyze Inca engineering","Understand Andean agriculture","Explore astronomical alignment"], curriculumTags: ["History","Engineering"], accessibilityFeatures: ["Captions"], avgRating: "4.8", reviewCount: 278, createdAt: new Date("2024-02-10"), updatedAt: new Date("2024-02-10") },
  { id: 5, title: "Amazon Rainforest Canopy", slug: "amazon-rainforest-canopy", description: "Ascend into the Amazon rainforest canopy and discover Earth's most biodiverse ecosystem.", category: "nature", subcategory: "Rainforest", stemType: "biology", gradeLevelMin: 4, gradeLevelMax: 12, durationSeconds: 1600, locationLat: "-3.4653", locationLng: "-62.2159", country: "Brazil", region: "South America", isPremium: false, isPublished: true, thumbnailUrl: "/experiences/amazon-rainforest.jpg", learningOutcomes: ["Identify rainforest layers","Explain nutrient cycling","Discuss deforestation impacts"], curriculumTags: ["Biology","Ecology"], accessibilityFeatures: ["Captions","Audio Description"], avgRating: "4.6", reviewCount: 198, createdAt: new Date("2024-02-15"), updatedAt: new Date("2024-02-15") },
  { id: 6, title: "Antarctic Ice Sheets", slug: "antarctic-ice-sheets", description: "Journey to Earth's frozen continent and explore vast ice sheets holding 70% of the planet's freshwater.", category: "stem", subcategory: "Climate Science", stemType: "physics", gradeLevelMin: 7, gradeLevelMax: 12, durationSeconds: 1300, locationLat: "-82.8628", locationLng: "-135.0000", country: "Antarctica", region: "Polar", isPremium: true, isPublished: true, thumbnailUrl: "/experiences/antarctica.jpg", learningOutcomes: ["Explain ice sheet dynamics","Analyze climate change indicators","Understand albedo effect"], curriculumTags: ["Climate Science","Physics"], accessibilityFeatures: ["Captions"], avgRating: "4.7", reviewCount: 156, createdAt: new Date("2024-03-01"), updatedAt: new Date("2024-03-01") },
  { id: 7, title: "Victoria Falls Thunder", slug: "victoria-falls-thunder", description: "Experience the thundering power of Victoria Falls, known as 'The Smoke That Thunders.'", category: "nature", subcategory: "Waterfalls", stemType: "physics", gradeLevelMin: 5, gradeLevelMax: 12, durationSeconds: 900, locationLat: "-17.9244", locationLng: "25.8560", country: "Zambia/Zimbabwe", region: "Southern Africa", isPremium: false, isPublished: true, thumbnailUrl: "/experiences/victoria-falls.jpg", learningOutcomes: ["Explain waterfall formation","Calculate potential energy","Explore cultural heritage"], curriculumTags: ["Geography","Physics"], accessibilityFeatures: ["Captions","Audio Description"], avgRating: "4.5", reviewCount: 134, createdAt: new Date("2024-03-05"), updatedAt: new Date("2024-03-05") },
  { id: 8, title: "Mount Everest Base Camp", slug: "mount-everest-base-camp", description: "Trek to the roof of the world. Explore geology, meteorology, and human challenges of Earth's highest peak.", category: "nature", subcategory: "Mountains", stemType: "physics", gradeLevelMin: 6, gradeLevelMax: 12, durationSeconds: 1400, locationLat: "28.0024", locationLng: "86.8525", country: "Nepal", region: "South Asia", isPremium: true, isPublished: true, thumbnailUrl: "/experiences/mount-everest.jpg", learningOutcomes: ["Explain tectonic plate formation","Understand atmospheric pressure","Explore Himalayan ecology"], curriculumTags: ["Geography","Physics","Biology"], accessibilityFeatures: ["Captions"], avgRating: "4.8", reviewCount: 267, createdAt: new Date("2024-03-10"), updatedAt: new Date("2024-03-10") },
  { id: 9, title: "Sahara Desert Dunes", slug: "sahara-desert-dunes", description: "Explore the world's largest hot desert. Discover how life thrives in extreme arid conditions.", category: "nature", subcategory: "Desert", stemType: "physics", gradeLevelMin: 5, gradeLevelMax: 12, durationSeconds: 1100, locationLat: "23.4162", locationLng: "25.6628", country: "Multiple", region: "North Africa", isPremium: false, isPublished: true, thumbnailUrl: "/experiences/sahara.jpg", learningOutcomes: ["Describe desert formation","Explain sand dune mechanics","Identify desert organisms"], curriculumTags: ["Geography","Physics"], accessibilityFeatures: ["Captions"], avgRating: "4.4", reviewCount: 112, createdAt: new Date("2024-03-15"), updatedAt: new Date("2024-03-15") },
  { id: 10, title: "Yellowstone Geysers", slug: "yellowstone-geysers", description: "Explore extraordinary geothermal features from Old Faithful to Grand Prismatic Spring.", category: "stem", subcategory: "Geothermal", stemType: "chemistry", gradeLevelMin: 6, gradeLevelMax: 12, durationSeconds: 1300, locationLat: "44.4280", locationLng: "-110.5885", country: "United States", region: "North America", isPremium: false, isPublished: true, thumbnailUrl: "/experiences/yellowstone.jpg", learningOutcomes: ["Explain geothermal chemistry","Identify extremophiles","Understand volcanic systems"], curriculumTags: ["Chemistry","Biology","Earth Science"], accessibilityFeatures: ["Captions","Audio Description"], avgRating: "4.7", reviewCount: 203, createdAt: new Date("2024-03-20"), updatedAt: new Date("2024-03-20") },
  { id: 11, title: "Petra: The Treasury", slug: "petra-the-treasury", description: "Walk through the Siq canyon and emerge before Al-Khazneh, the Treasury of Petra.", category: "history", subcategory: "Ancient Cities", stemType: "none", gradeLevelMin: 5, gradeLevelMax: 12, durationSeconds: 1000, locationLat: "30.3285", locationLng: "35.4444", country: "Jordan", region: "Middle East", isPremium: false, isPublished: true, thumbnailUrl: "/experiences/petra.jpg", learningOutcomes: ["Analyze Nabataean engineering","Understand trade routes","Explore rock-cut construction"], curriculumTags: ["History","Engineering"], accessibilityFeatures: ["Captions"], avgRating: "4.6", reviewCount: 178, createdAt: new Date("2024-03-25"), updatedAt: new Date("2024-03-25") },
  { id: 12, title: "Angkor Wat Temples", slug: "angkor-wat-temples", description: "Explore the world's largest religious monument with architectural symmetry and astronomical alignments.", category: "history", subcategory: "Temples", stemType: "none", gradeLevelMin: 5, gradeLevelMax: 12, durationSeconds: 1200, locationLat: "13.4125", locationLng: "103.8670", country: "Cambodia", region: "Southeast Asia", isPremium: false, isPublished: true, thumbnailUrl: "/experiences/angkor-wat.jpg", learningOutcomes: ["Analyze Khmer architecture","Understand Hindu cosmology","Explore hydraulic engineering"], curriculumTags: ["History","Architecture"], accessibilityFeatures: ["Captions"], avgRating: "4.7", reviewCount: 165, createdAt: new Date("2024-04-01"), updatedAt: new Date("2024-04-01") },
  { id: 13, title: "The Roman Colosseum", slug: "roman-colosseum", description: "Step inside the greatest amphitheater ever built. Learn about Roman engineering and gladiatorial combat.", category: "history", subcategory: "Ancient Rome", stemType: "none", gradeLevelMin: 5, gradeLevelMax: 12, durationSeconds: 1100, locationLat: "41.8902", locationLng: "12.4922", country: "Italy", region: "Europe", isPremium: false, isPublished: true, thumbnailUrl: "/experiences/colosseum.jpg", learningOutcomes: ["Understand Roman engineering","Explore social structure","Analyze structural innovations"], curriculumTags: ["History","Engineering"], accessibilityFeatures: ["Captions","Audio Description"], avgRating: "4.6", reviewCount: 234, createdAt: new Date("2024-04-05"), updatedAt: new Date("2024-04-05") },
  { id: 14, title: "Taj Mahal", slug: "taj-mahal", description: "Marvel at the jewel of Muslim architecture in India. Explore symmetrical gardens and marble inlay work.", category: "culture", subcategory: "Architecture", stemType: "none", gradeLevelMin: 4, gradeLevelMax: 12, durationSeconds: 900, locationLat: "27.1751", locationLng: "78.0421", country: "India", region: "South Asia", isPremium: false, isPublished: true, thumbnailUrl: "/experiences/taj-mahal.jpg", learningOutcomes: ["Analyze Mughal architecture","Understand symmetry in design","Explore cultural fusion"], curriculumTags: ["Art History","Architecture"], accessibilityFeatures: ["Captions"], avgRating: "4.5", reviewCount: 198, createdAt: new Date("2024-04-10"), updatedAt: new Date("2024-04-10") },
  { id: 15, title: "Northern Lights Norway", slug: "northern-lights-norway", description: "Witness the Aurora Borealis and understand the solar wind and magnetosphere interactions.", category: "stem", subcategory: "Astronomy", stemType: "physics", gradeLevelMin: 7, gradeLevelMax: 12, durationSeconds: 1000, locationLat: "69.6492", locationLng: "18.9553", country: "Norway", region: "Arctic Europe", isPremium: true, isPublished: true, thumbnailUrl: "/experiences/northern-lights.jpg", learningOutcomes: ["Explain solar wind interactions","Describe atmospheric excitation","Understand magnetic field protection"], curriculumTags: ["Physics","Astronomy"], accessibilityFeatures: ["Captions","Audio Description"], avgRating: "4.9", reviewCount: 289, createdAt: new Date("2024-04-15"), updatedAt: new Date("2024-04-15") },
  { id: 16, title: "Human Cell Explorer", slug: "human-cell-explorer", description: "Journey inside a living human cell. Explore organelles in stunning interactive 3D.", category: "stem", subcategory: "Cell Biology", stemType: "biology", gradeLevelMin: 6, gradeLevelMax: 12, durationSeconds: 2000, locationLat: null, locationLng: null, country: null, region: "Virtual Lab", isPremium: false, isPublished: true, thumbnailUrl: "/experiences/great-barrier-reef.jpg", learningOutcomes: ["Identify cell organelles","Explain central dogma","Describe cellular respiration"], curriculumTags: ["Biology","Molecular Biology"], accessibilityFeatures: ["Captions","Audio Description"], avgRating: "4.8", reviewCount: 178, createdAt: new Date("2024-04-20"), updatedAt: new Date("2024-04-20") },
  { id: 17, title: "Periodic Table & Reactions", slug: "periodic-table-reactions", description: "Master the elements with an interactive periodic table and virtual chemistry lab.", category: "stem", subcategory: "Chemistry", stemType: "chemistry", gradeLevelMin: 7, gradeLevelMax: 12, durationSeconds: 1800, locationLat: null, locationLng: null, country: null, region: "Virtual Lab", isPremium: false, isPublished: true, thumbnailUrl: "/experiences/yellowstone.jpg", learningOutcomes: ["Predict chemical bonding","Balance chemical equations","Explain reaction mechanisms"], curriculumTags: ["Chemistry","Physical Science"], accessibilityFeatures: ["Captions"], avgRating: "4.6", reviewCount: 145, createdAt: new Date("2024-04-25"), updatedAt: new Date("2024-04-25") },
  { id: 18, title: "Wave Physics Simulator", slug: "wave-physics-simulator", description: "Visualize the physics of waves, sound, and light. Interfere with wave patterns and explore the EM spectrum.", category: "stem", subcategory: "Physics", stemType: "physics", gradeLevelMin: 8, gradeLevelMax: 12, durationSeconds: 1600, locationLat: null, locationLng: null, country: null, region: "Virtual Lab", isPremium: false, isPublished: true, thumbnailUrl: "/experiences/northern-lights.jpg", learningOutcomes: ["Describe wave properties","Explain wave interference","Connect waves to real phenomena"], curriculumTags: ["Physics","Physical Science"], accessibilityFeatures: ["Captions","Audio Description"], avgRating: "4.5", reviewCount: 123, createdAt: new Date("2024-05-01"), updatedAt: new Date("2024-05-01") },
  { id: 19, title: "Ngorongoro Crater", slug: "ngorongoro-crater", description: "Descend into the world's largest inactive volcanic caldera with over 25,000 large animals.", category: "nature", subcategory: "Wildlife", stemType: "biology", gradeLevelMin: 4, gradeLevelMax: 12, durationSeconds: 1100, locationLat: "-3.1618", locationLng: "35.5878", country: "Tanzania", region: "East Africa", isPremium: true, isPublished: true, thumbnailUrl: "/experiences/serengeti.jpg", learningOutcomes: ["Understand volcanic caldera formation","Analyze predator-prey density","Explore East African Rift geology"], curriculumTags: ["Biology","Geology"], accessibilityFeatures: ["Captions"], avgRating: "4.7", reviewCount: 156, createdAt: new Date("2024-05-05"), updatedAt: new Date("2024-05-05") },
  { id: 20, title: "Galapagos Marine Ecosystem", slug: "galapagos-marine-ecosystem", description: "Dive into the unique ecosystem that inspired Darwin's theory of evolution.", category: "nature", subcategory: "Marine", stemType: "biology", gradeLevelMin: 6, gradeLevelMax: 12, durationSeconds: 1500, locationLat: "-0.9538", locationLng: "-90.9656", country: "Ecuador", region: "South Pacific", isPremium: true, isPublished: true, thumbnailUrl: "/experiences/great-barrier-reef.jpg", learningOutcomes: ["Explain adaptive radiation","Identify endemic species","Understand evolutionary biology"], curriculumTags: ["Biology","Evolution"], accessibilityFeatures: ["Captions","Audio Description"], avgRating: "4.8", reviewCount: 201, createdAt: new Date("2024-05-10"), updatedAt: new Date("2024-05-10") },
  { id: 21, title: "ISS Space Station Tour", slug: "iss-space-station-tour", description: "Float through the International Space Station and experience life in microgravity.", category: "stem", subcategory: "Space", stemType: "physics", gradeLevelMin: 5, gradeLevelMax: 12, durationSeconds: 1400, locationLat: null, locationLng: null, country: null, region: "Low Earth Orbit", isPremium: true, isPublished: true, thumbnailUrl: "/experiences/northern-lights.jpg", learningOutcomes: ["Explain orbital mechanics","Describe life support systems","Understand space cooperation"], curriculumTags: ["Physics","Astronomy"], accessibilityFeatures: ["Captions","Audio Description"], avgRating: "4.9", reviewCount: 267, createdAt: new Date("2024-05-15"), updatedAt: new Date("2024-05-15") },
];

const mockHotspots = [
  { id: 1, experienceId: 1, title: "Wildebeest Herd", description: "Over 1.5 million wildebeest migrate in a clockwise pattern following rainfall and fresh grazing.", yaw: "45.00", pitch: "5.00", iconType: "info" as const, relatedExperienceId: null as number | null, createdAt: new Date() },
  { id: 2, experienceId: 1, title: "Predator Zone", description: "Lions, cheetahs, and hyenas follow the migration, creating intense predator-prey interactions.", yaw: "-30.00", pitch: "-10.00", iconType: "quiz" as const, relatedExperienceId: null, createdAt: new Date() },
  { id: 3, experienceId: 2, title: "Vishnu Schist", description: "The oldest rock layer visible here is 1.75 billion years old.", yaw: "20.00", pitch: "15.00", iconType: "info" as const, relatedExperienceId: null, createdAt: new Date() },
  { id: 4, experienceId: 2, title: "Colorado River", description: "The river carved this canyon over 5-6 million years.", yaw: "-45.00", pitch: "-20.00", iconType: "info" as const, relatedExperienceId: null, createdAt: new Date() },
  { id: 5, experienceId: 3, title: "Coral Polyp", description: "Each coral head is made of thousands of tiny polyps.", yaw: "60.00", pitch: "10.00", iconType: "info" as const, relatedExperienceId: null, createdAt: new Date() },
  { id: 6, experienceId: 3, title: "Clownfish Anemone", description: "Clownfish and sea anemones share a mutualistic relationship.", yaw: "-60.00", pitch: "5.00", iconType: "quiz" as const, relatedExperienceId: null, createdAt: new Date() },
  { id: 7, experienceId: 4, title: "Intihuatana Stone", description: "This ritual stone served as an astronomical clock for the Incas.", yaw: "15.00", pitch: "20.00", iconType: "info" as const, relatedExperienceId: null, createdAt: new Date() },
  { id: 8, experienceId: 4, title: "Agricultural Terraces", description: "Terraces allowed the Incas to farm steep slopes and prevent erosion.", yaw: "-25.00", pitch: "-15.00", iconType: "info" as const, relatedExperienceId: null, createdAt: new Date() },
  { id: 9, experienceId: 5, title: "Emergent Layer", description: "The tallest trees reach 60+ meters to capture sunlight.", yaw: "30.00", pitch: "30.00", iconType: "info" as const, relatedExperienceId: null, createdAt: new Date() },
  { id: 10, experienceId: 5, title: "Canopy Layer", description: "90% of rainforest organisms live in the canopy layer.", yaw: "-40.00", pitch: "0.00", iconType: "quiz" as const, relatedExperienceId: null, createdAt: new Date() },
];

const mockQuizzes = [
  { id: 1, experienceId: 1, question: "Approximately how many wildebeest participate in the Great Migration?", options: ["500,000","1.5 million","3 million","500,000"], correctAnswerIndex: 1, explanation: "Over 1.5 million wildebeest make this the largest terrestrial mammal migration.", points: 10, createdAt: new Date() },
  { id: 2, experienceId: 2, question: "What is the age of the oldest visible rock layer in the Grand Canyon?", options: ["500 million years","1 billion years","1.75 billion years","3 billion years"], correctAnswerIndex: 2, explanation: "The Vishnu Schist is approximately 1.75 billion years old.", points: 10, createdAt: new Date() },
  { id: 3, experienceId: 3, question: "What is the primary threat facing coral reefs worldwide?", options: ["Overfishing","Coral bleaching from warming oceans","Ship anchor damage","Plastic pollution"], correctAnswerIndex: 1, explanation: "Rising ocean temperatures cause coral bleaching.", points: 10, createdAt: new Date() },
  { id: 4, experienceId: 4, question: "At what elevation is Machu Picchu located?", options: ["1,200m","2,430m","3,800m","4,200m"], correctAnswerIndex: 1, explanation: "Machu Picchu sits at 2,430 meters above sea level.", points: 10, createdAt: new Date() },
  { id: 5, experienceId: 5, question: "What percentage of rainforest species live in the canopy layer?", options: ["50%","70%","90%","30%"], correctAnswerIndex: 2, explanation: "90% of all organisms are found in the canopy layer.", points: 10, createdAt: new Date() },
];

export const experienceRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        category: z.string().optional(),
        subcategory: z.string().optional(),
        gradeLevel: z.number().optional(),
        search: z.string().optional(),
        sort: z.enum(["popular", "newest", "relevant"]).default("popular"),
        limit: z.number().default(20),
        offset: z.number().default(0),
      }).optional()
    )
    .query(async ({ input }) => {
      try {
        const db = getDb();
        let query = db.select().from(experiences);
        const rows = await query;
        if (rows && rows.length > 0) {
          let filtered = rows;
          if (input?.category) {
            filtered = filtered.filter((r) => r.category === input.category);
          }
          if (input?.search) {
            const s = input.search.toLowerCase();
            filtered = filtered.filter((r) =>
              r.title.toLowerCase().includes(s) || r.description.toLowerCase().includes(s)
            );
          }
          if (input?.gradeLevel) {
            filtered = filtered.filter(
              (r) => r.gradeLevelMin <= input.gradeLevel! && r.gradeLevelMax >= input.gradeLevel!
            );
          }
          return filtered.slice(input?.offset ?? 0, (input?.offset ?? 0) + (input?.limit ?? 20));
        }
      } catch {
        // fallback to mock data
      }
      let filtered = [...mockExperiences];
      if (input?.category) {
        filtered = filtered.filter((r) => r.category === input.category);
      }
      if (input?.search) {
        const s = input.search.toLowerCase();
        filtered = filtered.filter((r) =>
          r.title.toLowerCase().includes(s) || r.description.toLowerCase().includes(s)
        );
      }
      if (input?.gradeLevel) {
        filtered = filtered.filter(
          (r) => r.gradeLevelMin <= input.gradeLevel! && r.gradeLevelMax >= input.gradeLevel!
        );
      }
      return filtered.slice(input?.offset ?? 0, (input?.offset ?? 0) + (input?.limit ?? 20));
    }),

  getBySlug: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      try {
        const db = getDb();
        const rows = await db.select().from(experiences).where(eq(experiences.slug, input.slug));
        if (rows && rows.length > 0) return rows[0];
      } catch {
        // fallback
      }
      return mockExperiences.find((e) => e.slug === input.slug) ?? null;
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      try {
        const db = getDb();
        const rows = await db.select().from(experiences).where(eq(experiences.id, input.id));
        if (rows && rows.length > 0) return rows[0];
      } catch {
        // fallback
      }
      return mockExperiences.find((e) => e.id === input.id) ?? null;
    }),

  featured: publicQuery.query(async () => {
    try {
      const db = getDb();
      const rows = await db.select().from(experiences).limit(6);
      if (rows && rows.length > 0) return rows;
    } catch {
      // fallback
    }
    return mockExperiences.slice(0, 6);
  }),

  categories: publicQuery.query(async () => {
    const cats = [
      { name: "nature", label: "Nature", count: 11 },
      { name: "history", label: "History", count: 4 },
      { name: "stem", label: "STEM", count: 6 },
      { name: "culture", label: "Culture", count: 1 },
    ];
    const subs = ["Wildlife", "Geology", "Marine", "Ancient Civilizations", "Rainforest", "Climate Science", "Waterfalls", "Mountains", "Desert", "Geothermal", "Ancient Cities", "Temples", "Ancient Rome", "Architecture", "Astronomy", "Cell Biology", "Chemistry", "Physics", "Space"];
    return { categories: cats, subcategories: subs };
  }),
});

export const hotspotRouter = createRouter({
  listByExperience: publicQuery
    .input(z.object({ experienceId: z.number() }))
    .query(async ({ input }) => {
      try {
        const db = getDb();
        const rows = await db.select().from(hotspots).where(eq(hotspots.experienceId, input.experienceId));
        if (rows && rows.length > 0) return rows;
      } catch {
        // fallback
      }
      return mockHotspots.filter((h) => h.experienceId === input.experienceId);
    }),
});

export const quizRouter = createRouter({
  listByExperience: publicQuery
    .input(z.object({ experienceId: z.number() }))
    .query(async ({ input }) => {
      try {
        const db = getDb();
        const rows = await db.select().from(quizzes).where(eq(quizzes.experienceId, input.experienceId));
        if (rows && rows.length > 0) return rows;
      } catch {
        // fallback
      }
      return mockQuizzes.filter((q) => q.experienceId === input.experienceId);
    }),
});
