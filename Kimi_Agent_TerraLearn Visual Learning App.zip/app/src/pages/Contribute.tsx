import { useState } from "react";
import {
  Upload,
  Camera,
  Video,
  Mic,
  MapPin,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  Info,
  Award,
  Globe,
} from "lucide-react";

const steps = [
  { title: "Content Type", desc: "Choose what you're uploading" },
  { title: "Upload Files", desc: "Add your media files" },
  { title: "Metadata", desc: "Describe your content" },
  { title: "Review", desc: "Submit for processing" },
];

const contentTypes = [
  { icon: Camera, label: "360° Photo Set", desc: "Stitched panoramic images" },
  { icon: Video, label: "360° Video", desc: "Immersive video footage" },
  { icon: Camera, label: "Standard Photos", desc: "High-resolution images" },
  { icon: Video, label: "Video Clips", desc: "Short video segments" },
  { icon: Mic, label: "Audio Narration", desc: "Voice-over recordings" },
];

const guidelines = [
  { title: "Image Overlap", desc: "Ensure 30%+ overlap between adjacent photos for proper stitching." },
  { title: "Consistent Exposure", desc: "Lock exposure settings to avoid brightness variations." },
  { title: "Stable Footage", desc: "Use a tripod or stabilizer for smooth video capture." },
  { title: "Audio Quality", desc: "Record narration in a quiet environment with a quality microphone." },
  { title: "Safety First", desc: "Always prioritize personal safety and local regulations." },
  { title: "Ethical Considerations", desc: "Respect wildlife, indigenous sites, and private property." },
];

export default function Contribute() {
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [uploaded, setUploaded] = useState(false);

  const handleSubmit = () => {
    setUploaded(true);
  };

  return (
    <div className="min-h-full px-4 lg:px-6 py-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-[#F4F6F8]">Contribute Content</h1>
        <p className="text-sm text-[#8E92A4] mt-1">Help us digitize the world. Share your photos, videos, and 360° captures.</p>
      </div>

      {uploaded ? (
        <div className="max-w-lg mx-auto text-center py-16">
          <div className="w-20 h-20 rounded-full bg-[#10B981]/15 flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-10 h-10 text-[#10B981]" />
          </div>
          <h2 className="text-2xl font-bold text-[#F4F6F8]">Content Submitted!</h2>
          <p className="text-sm text-[#8E92A4] mt-2">
            Thank you for your contribution. Our AI will process and stitch your content. You'll receive an email when it's published.
          </p>
          <div className="mt-6 p-4 rounded-xl bg-[#23262F] border border-[#2C2F3A] text-left">
            <p className="text-xs text-[#8E92A4] mb-2">Processing Pipeline:</p>
            <div className="space-y-2">
              {["Source Collection", "Feature Matching", "Alignment & Blending", "AI Enhancement"].map((step, i) => (
                <div key={step} className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-full bg-[#3B82F6]/15 flex items-center justify-center">
                    <span className="text-[10px] text-[#3B82F6] font-bold">{i + 1}</span>
                  </div>
                  <span className="text-xs text-[#8E92A4]">{step}</span>
                  {i < 2 && <CheckCircle2 className="w-3 h-3 text-[#10B981] ml-auto" />}
                </div>
              ))}
            </div>
          </div>
          <button
            onClick={() => { setUploaded(false); setCurrentStep(0); setSelectedType(null); }}
            className="mt-6 px-6 py-2.5 rounded-xl bg-[#3B82F6] text-white text-sm font-medium hover:bg-[#2563EB] transition-all"
          >
            Upload More
          </button>
        </div>
      ) : (
        <>
          {/* Stepper */}
          <div className="flex items-center gap-2 mb-8 overflow-x-auto pb-2">
            {steps.map((step, i) => (
              <div key={i} className="flex items-center gap-2 shrink-0">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                  i <= currentStep ? "bg-[#3B82F6] text-white" : "bg-[#2C2F3A] text-[#8E92A4]"
                }`}>
                  {i < currentStep ? <CheckCircle2 className="w-4 h-4" /> : i + 1}
                </div>
                <div className="hidden sm:block">
                  <p className={`text-xs font-medium ${i <= currentStep ? "text-[#F4F6F8]" : "text-[#8E92A4]"}`}>{step.title}</p>
                  <p className="text-[10px] text-[#4D5060]">{step.desc}</p>
                </div>
                {i < steps.length - 1 && <ChevronRight className="w-4 h-4 text-[#4D5060] mx-1" />}
              </div>
            ))}
          </div>

          {/* Step Content */}
          <div className="max-w-2xl">
            {currentStep === 0 && (
              <div>
                <h2 className="text-lg font-semibold text-[#F4F6F8] mb-4">What are you uploading?</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {contentTypes.map((type) => (
                    <button
                      key={type.label}
                      onClick={() => setSelectedType(type.label)}
                      className={`p-4 rounded-xl border text-left transition-all ${
                        selectedType === type.label
                          ? "bg-[#3B82F6]/10 border-[#3B82F6]/50"
                          : "bg-[#23262F] border-[#2C2F3A] hover:border-[#4D5060]"
                      }`}
                    >
                      <type.icon className={`w-6 h-6 mb-2 ${selectedType === type.label ? "text-[#3B82F6]" : "text-[#8E92A4]"}`} />
                      <h3 className="text-sm font-medium text-[#F4F6F8]">{type.label}</h3>
                      <p className="text-xs text-[#8E92A4] mt-1">{type.desc}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {currentStep === 1 && (
              <div>
                <h2 className="text-lg font-semibold text-[#F4F6F8] mb-4">Upload your files</h2>
                <div
                  onDragEnter={() => setIsDragging(true)}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={() => setIsDragging(false)}
                  className={`border-2 border-dashed rounded-xl p-12 text-center transition-all ${
                    isDragging ? "border-[#3B82F6] bg-[#3B82F6]/5" : "border-[#2C2F3A] bg-[#23262F]"
                  }`}
                >
                  <Upload className={`w-10 h-10 mx-auto mb-3 ${isDragging ? "text-[#3B82F6]" : "text-[#4D5060]"}`} />
                  <p className="text-sm text-[#F4F6F8]">Drag and drop files here</p>
                  <p className="text-xs text-[#8E92A4] mt-1">or click to browse</p>
                  <p className="text-[10px] text-[#4D5060] mt-3">Supports JPG, PNG, MP4, MOV up to 500MB</p>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-4">
                <h2 className="text-lg font-semibold text-[#F4F6F8] mb-4">Add metadata</h2>
                <div>
                  <label className="text-xs text-[#8E92A4] uppercase tracking-wider">Title</label>
                  <input type="text" placeholder="Give your experience a name" className="w-full mt-1 px-4 py-2.5 rounded-xl bg-[#23262F] border border-[#2C2F3A] text-sm text-[#F4F6F8] placeholder:text-[#4D5060] focus:outline-none focus:border-[#3B82F6]" />
                </div>
                <div>
                  <label className="text-xs text-[#8E92A4] uppercase tracking-wider">Location</label>
                  <div className="relative mt-1">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8E92A4]" />
                    <input type="text" placeholder="Search for a location" className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#23262F] border border-[#2C2F3A] text-sm text-[#F4F6F8] placeholder:text-[#4D5060] focus:outline-none focus:border-[#3B82F6]" />
                  </div>
                </div>
                <div>
                  <label className="text-xs text-[#8E92A4] uppercase tracking-wider">Description</label>
                  <textarea placeholder="Describe what learners will experience" rows={3} className="w-full mt-1 px-4 py-2.5 rounded-xl bg-[#23262F] border border-[#2C2F3A] text-sm text-[#F4F6F8] placeholder:text-[#4D5060] focus:outline-none focus:border-[#3B82F6] resize-none" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-[#8E92A4] uppercase tracking-wider">Grade Level Min</label>
                    <select className="w-full mt-1 px-4 py-2.5 rounded-xl bg-[#23262F] border border-[#2C2F3A] text-sm text-[#F4F6F8] focus:outline-none focus:border-[#3B82F6]">
                      {[1, 2, 3, 4, 5, 6].map((g) => <option key={g} value={g}>Grade {g}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-[#8E92A4] uppercase tracking-wider">Grade Level Max</label>
                    <select className="w-full mt-1 px-4 py-2.5 rounded-xl bg-[#23262F] border border-[#2C2F3A] text-sm text-[#F4F6F8] focus:outline-none focus:border-[#3B82F6]">
                      {[7, 8, 9, 10, 11, 12].map((g) => <option key={g} value={g}>Grade {g}</option>)}
                    </select>
                  </div>
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div>
                <h2 className="text-lg font-semibold text-[#F4F6F8] mb-4">Review & Submit</h2>
                <div className="bg-[#23262F] rounded-xl border border-[#2C2F3A] p-5 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#8E92A4]">Content Type</span>
                    <span className="text-sm text-[#F4F6F8]">{selectedType || "360° Photo Set"}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#8E92A4]">Files</span>
                    <span className="text-sm text-[#F4F6F8]">12 photos (48MB)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#8E92A4]">License</span>
                    <span className="text-sm text-[#F4F6F8]">CC BY-SA 4.0</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#8E92A4]">AI Processing</span>
                    <span className="text-sm text-[#10B981]">Enabled</span>
                  </div>
                  <div className="pt-3 border-t border-[#2C2F3A]">
                    <p className="text-xs text-[#8E92A4]">
                      By submitting, you agree to our content guidelines and grant TerraLearn the right to process and distribute your content.
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleSubmit}
                  className="w-full mt-4 py-3 rounded-xl bg-[#3B82F6] text-white font-medium hover:bg-[#2563EB] transition-all"
                >
                  Submit for Processing
                </button>
              </div>
            )}
          </div>

          {/* Navigation */}
          {currentStep < 3 && (
            <div className="flex items-center gap-3 mt-6">
              {currentStep > 0 && (
                <button
                  onClick={() => setCurrentStep(currentStep - 1)}
                  className="px-4 py-2.5 rounded-xl bg-[#23262F] border border-[#2C2F3A] text-[#F4F6F8] text-sm hover:bg-[#2C2F3A] transition-all flex items-center gap-2"
                >
                  <ChevronLeft className="w-4 h-4" /> Back
                </button>
              )}
              <button
                onClick={() => setCurrentStep(currentStep + 1)}
                disabled={currentStep === 0 && !selectedType}
                className="ml-auto px-4 py-2.5 rounded-xl bg-[#3B82F6] text-white text-sm hover:bg-[#2563EB] transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Guidelines */}
          <div className="mt-10 pt-6 border-t border-[#2C2F3A]">
            <h3 className="text-sm font-semibold text-[#F4F6F8] mb-4 flex items-center gap-2">
              <Info className="w-4 h-4 text-[#3B82F6]" /> Capture Guidelines
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {guidelines.map((g) => (
                <div key={g.title} className="p-3 rounded-lg bg-[#23262F] border border-[#2C2F3A]">
                  <h4 className="text-xs font-medium text-[#F4F6F8]">{g.title}</h4>
                  <p className="text-[11px] text-[#8E92A4] mt-1">{g.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Leaderboard teaser */}
          <div className="mt-6 bg-[#23262F] rounded-xl border border-[#2C2F3A] p-5">
            <h3 className="text-sm font-semibold text-[#F4F6F8] mb-3 flex items-center gap-2">
              <Award className="w-4 h-4 text-[#F59E0B]" /> Top Contributors
            </h3>
            <div className="space-y-2">
              {[
                { name: "Sarah M.", contributions: 23, countries: 8 },
                { name: "David K.", contributions: 19, countries: 6 },
                { name: "Lisa T.", contributions: 15, countries: 5 },
              ].map((user, i) => (
                <div key={user.name} className="flex items-center gap-3 p-2 rounded-lg bg-[#181A20]">
                  <span className="w-5 text-center text-xs font-bold text-[#4D5060] font-display">{i + 1}</span>
                  <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#3B82F6] to-[#10B981] flex items-center justify-center text-[10px] font-bold text-white">
                    {user.name.charAt(0)}
                  </div>
                  <span className="text-sm text-[#F4F6F8] flex-1">{user.name}</span>
                  <span className="text-xs text-[#8E92A4]">{user.contributions} uploads</span>
                  <span className="text-xs text-[#8E92A4] flex items-center gap-1">
                    <Globe className="w-3 h-3" />{user.countries}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
