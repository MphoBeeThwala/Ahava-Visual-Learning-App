import { authRouter } from "./auth-router";
import { experienceRouter, hotspotRouter, quizRouter } from "./experience-router";
import { progressRouter } from "./progress-router";
import { classRouter } from "./class-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  experience: experienceRouter,
  hotspot: hotspotRouter,
  quiz: quizRouter,
  progress: progressRouter,
  class: classRouter,
});

export type AppRouter = typeof appRouter;
