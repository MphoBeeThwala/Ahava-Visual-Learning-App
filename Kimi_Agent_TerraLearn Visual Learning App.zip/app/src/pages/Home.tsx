import { useEffect, useRef } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import {
  Globe,
  Clock,
  Star,
  MapPin,
  TrendingUp,
  Award,
  BookOpen,
  Flame,
  ChevronRight,
  Play,
  Crown,
} from "lucide-react";

function GlobalKnowledgeMap() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    let time = 0;

    const resize = () => {
      canvas.width = canvas.offsetWidth * window.devicePixelRatio;
      canvas.height = canvas.offsetHeight * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };
    resize();
    window.addEventListener("resize", resize);

    const points: { x: number; y: number; r: number; speed: number; color: string; connections: number[] }[] = [];
    const colors = ["#3B82F6", "#10B981", "#F4F6F8", "#8B5CF6", "#F59E0B"];
    const numPoints = 60;

    for (let i = 0; i < numPoints; i++) {
      points.push({
        x: Math.random() * canvas.offsetWidth,
        y: Math.random() * canvas.offsetHeight,
        r: Math.random() * 2 + 1,
        speed: Math.random() * 0.3 + 0.1,
        color: colors[Math.floor(Math.random() * colors.length)],
        connections: [],
      });
    }

    const animate = () => {
      time += 0.005;
      ctx!.clearRect(0, 0, canvas.offsetWidth, canvas.offsetHeight);

      // Draw connections
      for (let i = 0; i < points.length; i++) {
        for (let j = i + 1; j < points.length; j++) {
          const dx = points[i].x - points[j].x;
          const dy = points[i].y - points[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 120) {
            ctx!.beginPath();
            ctx!.strokeStyle = `rgba(59, 130, 246, ${0.15 * (1 - dist / 120)})`;
            ctx!.lineWidth = 0.5;
            ctx!.moveTo(points[i].x, points[i].y);
            ctx!.lineTo(points[j].x, points[j].y);
            ctx!.stroke();
          }
        }
      }

      // Draw points
      for (const p of points) {
        p.y -= p.speed;
        if (p.y < -10) {
          p.y = canvas.offsetHeight + 10;
          p.x = Math.random() * canvas.offsetWidth;
        }

        ctx!.beginPath();
        ctx!.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx!.fillStyle = p.color;
        ctx!.fill();

        // Glow
        ctx!.beginPath();
        ctx!.arc(p.x, p.y, p.r * 3, 0, Math.PI * 2);
        const grad = ctx!.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 3);
        grad.addColorStop(0, p.color + "40");
        grad.addColorStop(1, "transparent");
        ctx!.fillStyle = grad;
        ctx!.fill();
      }

      animId = requestAnimationFrame(animate);
    };
    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />;
}

function StatCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: string; color: string }) {
  return (
    <div className="bg-[#23262F] rounded-xl p-4 border border-[#2C2F3A]">
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center`} style={{ backgroundColor: color + "20" }}>
          <Icon className="w-5 h-5" style={{ color }} />
        </div>
        <div>
          <p className="text-2xl font-bold text-[#F4F6F8] font-display">{value}</p>
          <p className="text-xs text-[#8E92A4] uppercase tracking-wider">{label}</p>
        </div>
      </div>
    </div>
  );
}

function ContinueCard({ title, thumbnail, progress, category }: { title: string; thumbnail: string; progress: number; category: string }) {
  return (
    <Link to={`/explore`} className="group relative overflow-hidden rounded-xl bg-[#23262F] border border-[#2C2F3A] hover:border-[#3B82F6]/50 transition-all duration-300">
      <div className="aspect-video overflow-hidden">
        <img src={thumbnail} alt={title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#181A20] via-transparent to-transparent" />
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-4">
        <span className="text-[10px] uppercase tracking-wider text-[#3B82F6] font-medium">{category}</span>
        <h3 className="text-sm font-semibold text-[#F4F6F8] mt-1">{title}</h3>
        <div className="mt-2 flex items-center gap-2">
          <div className="flex-1 h-1.5 bg-[#2C2F3A] rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-[#3B82F6] to-[#10B981] rounded-full transition-all duration-500" style={{ width: `${progress}%` }} />
          </div>
          <span className="text-xs text-[#8E92A4] font-display">{progress}%</span>
        </div>
      </div>
      <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-[#3B82F6]/90 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
        <Play className="w-4 h-4 text-white ml-0.5" />
      </div>
    </Link>
  );
}

export default function Home() {
  const { data: featured } = trpc.experience.featured.useQuery();
  const { data: progressStats } = trpc.progress.stats.useQuery(undefined, { retry: false });

  const stats = [
    { icon: Globe, label: "Experiences", value: "2,400+", color: "#3B82F6" },
    { icon: MapPin, label: "Countries", value: "147", color: "#10B981" },
    { icon: BookOpen, label: "Students", value: "500K+", color: "#F59E0B" },
    { icon: Award, label: "Free for Schools", value: "100%", color: "#8B5CF6" },
  ];

  const continueLearning = [
    { title: "Great Barrier Reef Dive", thumbnail: "/experiences/great-barrier-reef.jpg", progress: 75, category: "Marine Biology" },
    { title: "Yellowstone Geysers", thumbnail: "/experiences/yellowstone.jpg", progress: 30, category: "Chemistry" },
    { title: "Northern Lights Norway", thumbnail: "/experiences/northern-lights.jpg", progress: 0, category: "Physics" },
  ];

  return (
    <div className="min-h-full">
      {/* Hero Section */}
      <section className="relative h-[400px] lg:h-[450px] overflow-hidden">
        <div className="absolute inset-0">
          <img src="/experiences/grand-canyon.jpg" alt="Hero" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#181A20] via-[#181A20]/70 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#181A20] via-transparent to-transparent" />
        </div>

        <div className="relative z-10 flex flex-col justify-center h-full px-6 lg:px-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#3B82F6]/20 border border-[#3B82F6]/30 w-fit mb-4">
            <Flame className="w-3.5 h-3.5 text-[#F59E0B]" />
            <span className="text-xs font-medium text-[#3B82F6]">7-day learning streak!</span>
          </div>
          <h1 className="text-3xl lg:text-5xl font-bold text-[#F4F6F8] leading-tight">
            See the World.<br />
            <span className="text-[#3B82F6]">Learn the World.</span>
          </h1>
          <p className="mt-4 text-base lg:text-lg text-[#8E92A4] max-w-xl">
            Immersive field trips for every student — no bus ticket required. Explore 2,400+ experiences across 147 countries.
          </p>
          <div className="mt-6 flex items-center gap-3">
            <Link
              to="/explore"
              className="px-6 py-3 rounded-xl bg-[#3B82F6] text-white font-medium hover:bg-[#2563EB] transition-all flex items-center gap-2"
            >
              <Globe className="w-4 h-4" />
              Start Learning
            </Link>
            <Link
              to="/tourism"
              className="px-6 py-3 rounded-xl bg-[#23262F] border border-[#2C2F3A] text-[#F4F6F8] font-medium hover:bg-[#2C2F3A] transition-all flex items-center gap-2"
            >
              <Crown className="w-4 h-4" />
              Explore as Tourist
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="px-6 lg:px-10 py-6 -mt-8 relative z-20">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
          {stats.map((stat) => (
            <StatCard key={stat.label} {...stat} />
          ))}
        </div>
      </section>

      {/* Continue Learning */}
      <section className="px-6 lg:px-10 py-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-[#F4F6F8]">Continue Learning</h2>
          <Link to="/profile" className="text-sm text-[#3B82F6] hover:text-[#60A5FA] flex items-center gap-1 transition-colors">
            View All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {continueLearning.map((item) => (
            <ContinueCard key={item.title} {...item} />
          ))}
        </div>
      </section>

      {/* Featured Experiences */}
      <section className="px-6 lg:px-10 py-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-[#F4F6F8]">Featured Experiences</h2>
          <Link to="/explore" className="text-sm text-[#3B82F6] hover:text-[#60A5FA] flex items-center gap-1 transition-colors">
            Browse All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {(featured ?? []).slice(0, 6).map((exp: any) => (
            <Link
              key={exp.id}
              to={`/experience/${exp.slug}`}
              className="group bg-[#23262F] rounded-xl border border-[#2C2F3A] overflow-hidden hover:border-[#3B82F6]/50 transition-all duration-300"
            >
              <div className="aspect-video overflow-hidden">
                <img src={exp.thumbnailUrl} alt={exp.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              </div>
              <div className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[10px] uppercase tracking-wider text-[#3B82F6] font-medium">{exp.category}</span>
                  {exp.isPremium && (
                    <span className="text-[10px] uppercase tracking-wider text-[#F59E0B] font-medium">Premium</span>
                  )}
                </div>
                <h3 className="text-sm font-semibold text-[#F4F6F8] group-hover:text-[#3B82F6] transition-colors">{exp.title}</h3>
                <div className="flex items-center gap-3 mt-2 text-xs text-[#8E92A4]">
                  <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{exp.country}</span>
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{Math.floor(exp.durationSeconds / 60)} min</span>
                  <span className="flex items-center gap-1"><Star className="w-3 h-3 text-[#F59E0B]" />{exp.avgRating}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Global Knowledge Map */}
      <section className="px-6 lg:px-10 py-6">
        <div className="bg-[#23262F] rounded-2xl border border-[#2C2F3A] overflow-hidden relative h-[300px]">
          <GlobalKnowledgeMap />
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <Globe className="w-12 h-12 text-[#3B82F6] mb-3 animate-float" />
            <h3 className="text-2xl font-bold text-[#F4F6F8]">Global Knowledge Map</h3>
            <p className="text-sm text-[#8E92A4] mt-1">You've explored {progressStats?.experiencesExplored ?? 4} of {progressStats?.totalExperiences ?? 21} experiences</p>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="px-6 lg:px-10 py-8">
        <h2 className="text-xl font-semibold text-[#F4F6F8] mb-6 text-center">How TerraLearn Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { step: "01", title: "Browse & Discover", desc: "Explore thousands of immersive experiences across nature, history, STEM, and culture.", icon: Globe, color: "#3B82F6" },
            { step: "02", title: "Immerse in 360°", desc: "Step inside stunning panoramic views with interactive hotspots and guided narration.", icon: TrendingUp, color: "#10B981" },
            { step: "03", title: "Learn & Quiz", desc: "Test your knowledge with interactive quizzes and earn achievements as you progress.", icon: Award, color: "#F59E0B" },
          ].map((item) => (
            <div key={item.step} className="text-center p-6 rounded-xl bg-[#23262F] border border-[#2C2F3A]">
              <div className="w-14 h-14 rounded-xl mx-auto mb-4 flex items-center justify-center" style={{ backgroundColor: item.color + "20" }}>
                <item.icon className="w-7 h-7" style={{ color: item.color }} />
              </div>
              <span className="text-xs font-display text-[#4D5060] font-bold">{item.step}</span>
              <h3 className="text-lg font-semibold text-[#F4F6F8] mt-1">{item.title}</h3>
              <p className="text-sm text-[#8E92A4] mt-2">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* STEM Lab CTA */}
      <section className="px-6 lg:px-10 py-8 mb-8">
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#3B82F6]/20 via-[#8B5CF6]/20 to-[#10B981]/20 border border-[#3B82F6]/30 p-8">
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h2 className="text-2xl font-bold text-[#F4F6F8]">Interactive STEM Laboratory</h2>
              <p className="text-[#8E92A4] mt-2 max-w-lg">
                Explore biology, chemistry, and physics through interactive 3D simulations. Dissect virtual organisms, build molecules, and visualize wave physics.
              </p>
            </div>
            <Link
              to="/lab"
              className="px-6 py-3 rounded-xl bg-[#3B82F6] text-white font-medium hover:bg-[#2563EB] transition-all flex items-center gap-2 whitespace-nowrap"
            >
              <TrendingUp className="w-4 h-4" />
              Enter STEM Lab
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
