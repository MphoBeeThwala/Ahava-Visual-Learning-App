import { useState, useEffect, useRef } from "react";
import {
  Dna,
  FlaskConical,
  Atom,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Play,
  Pause,
  ChevronRight,
  Microscope,
  Beaker,
  Waves,
} from "lucide-react";

type LabTab = "biology" | "chemistry" | "physics";

// ─── Biology: Interactive Cell ───
function BiologyLab() {
  const [activeOrganelle, setActiveOrganelle] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);

  const organelles = [
    { id: "nucleus", name: "Nucleus", x: 50, y: 45, r: 18, color: "#8B5CF6", desc: "The control center of the cell. Contains DNA and directs all cellular activities including growth and reproduction." },
    { id: "mitochondria", name: "Mitochondria", x: 28, y: 30, r: 10, color: "#F59E0B", desc: "The powerhouse of the cell. Converts glucose and oxygen into ATP through cellular respiration." },
    { id: "mitochondria2", name: "Mitochondria", x: 72, y: 60, r: 10, color: "#F59E0B", desc: "The powerhouse of the cell. Produces ATP energy through the Krebs cycle and electron transport chain." },
    { id: "er", name: "Endoplasmic Reticulum", x: 35, y: 55, r: 12, color: "#3B82F6", desc: "A network of membranes involved in protein and lipid synthesis. Rough ER has ribosomes; Smooth ER does not." },
    { id: "golgi", name: "Golgi Apparatus", x: 65, y: 35, r: 10, color: "#10B981", desc: "Packages and modifies proteins and lipids into vesicles for transport within or secretion from the cell." },
    { id: "ribosome", name: "Ribosome", x: 42, y: 38, r: 4, color: "#EF4444", desc: "Protein factories that read mRNA and assemble amino acids into polypeptide chains." },
    { id: "ribosome2", name: "Ribosome", x: 58, y: 52, r: 4, color: "#EF4444", desc: "Protein factories that read mRNA and assemble amino acids into polypeptide chains." },
    { id: "lysosome", name: "Lysosome", x: 40, y: 65, r: 6, color: "#EC4899", desc: "Contains digestive enzymes to break down waste materials, cellular debris, and foreign invaders." },
    { id: "membrane", name: "Cell Membrane", x: 50, y: 50, r: 45, color: "#06B6D4", desc: "A phospholipid bilayer that controls what enters and exits the cell. Contains proteins for transport and signaling." },
  ];

  const active = organelles.find((o) => o.id === activeOrganelle);

  return (
    <div className="flex flex-col lg:flex-row gap-4 h-full">
      <div className="flex-1 relative bg-[#0D0F17] rounded-xl overflow-hidden border border-[#2C2F3A]">
        {/* Cell SVG */}
        <svg viewBox="0 0 100 100" className="w-full h-full" style={{ transform: `scale(${zoom})`, transition: "transform 0.3s ease" }}>
          {/* Cytoplasm background */}
          <circle cx="50" cy="50" r="45" fill="#1a1f2e" stroke="#06B6D433" strokeWidth="0.5" />

          {/* Organelles */}
          {organelles.map((org) => (
            <g key={org.id} className="cursor-pointer" onClick={() => setActiveOrganelle(org.id)}>
              {org.id === "membrane" ? (
                <circle cx={org.x} cy={org.y} r={org.r} fill="none" stroke={org.color} strokeWidth="0.8" strokeDasharray="2 1" opacity={0.6} />
              ) : org.id === "er" ? (
                <>
                  <ellipse cx={org.x} cy={org.y} rx={org.r} ry={org.r * 0.6} fill={org.color + "30"} stroke={org.color} strokeWidth="0.5" />
                  <ellipse cx={org.x + 5} cy={org.y - 2} rx={org.r * 0.7} ry={org.r * 0.4} fill={org.color + "20"} stroke={org.color} strokeWidth="0.3" />
                </>
              ) : org.id.startsWith("mitochondria") ? (
                <ellipse cx={org.x} cy={org.y} rx={org.r} ry={org.r * 0.6} fill={org.color + "40"} stroke={org.color} strokeWidth="0.5">
                  <animate attributeName="opacity" values="0.7;1;0.7" dur="3s" repeatCount="indefinite" />
                </ellipse>
              ) : (
                <circle cx={org.x} cy={org.y} r={org.r} fill={org.color + "35"} stroke={org.color} strokeWidth="0.5">
                  {org.id === "nucleus" && <animate attributeName="r" values="18;18.5;18" dur="4s" repeatCount="indefinite" />}
                </circle>
              )}
              {activeOrganelle === org.id && (
                <circle cx={org.x} cy={org.y} r={org.r + 2} fill="none" stroke={org.color} strokeWidth="0.8" opacity={0.8}>
                  <animate attributeName="r" values={`${org.r + 1};${org.r + 3};${org.r + 1}`} dur="1.5s" repeatCount="indefinite" />
                  <animate attributeName="opacity" values="0.8;0.3;0.8" dur="1.5s" repeatCount="indefinite" />
                </circle>
              )}
            </g>
          ))}

          {/* Labels */}
          {organelles.filter(o => o.r > 8).map((org) => (
            <text key={`label-${org.id}`} x={org.x} y={org.y + 1} textAnchor="middle" fill="#F4F6F8" fontSize="2.5" fontWeight="500" pointerEvents="none">
              {org.name}
            </text>
          ))}
        </svg>

        {/* Zoom controls */}
        <div className="absolute bottom-3 right-3 flex flex-col gap-1">
          <button onClick={() => setZoom(Math.min(2, zoom + 0.2))} className="w-8 h-8 rounded-lg bg-[#23262F] border border-[#2C2F3A] flex items-center justify-center text-[#8E92A4] hover:text-[#F4F6F8] transition-all">
            <ZoomIn className="w-4 h-4" />
          </button>
          <button onClick={() => setZoom(Math.max(0.5, zoom - 0.2))} className="w-8 h-8 rounded-lg bg-[#23262F] border border-[#2C2F3A] flex items-center justify-center text-[#8E92A4] hover:text-[#F4F6F8] transition-all">
            <ZoomOut className="w-4 h-4" />
          </button>
          <button onClick={() => { setZoom(1); setActiveOrganelle(null); }} className="w-8 h-8 rounded-lg bg-[#23262F] border border-[#2C2F3A] flex items-center justify-center text-[#8E92A4] hover:text-[#F4F6F8] transition-all">
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        <div className="absolute top-3 left-3 px-3 py-1.5 rounded-lg bg-[#10B981]/15 border border-[#10B981]/30">
          <span className="text-[10px] uppercase tracking-wider text-[#10B981] font-bold">Interactive Cell Model</span>
        </div>
      </div>

      {/* Info Panel */}
      <div className="w-full lg:w-[320px] bg-[#23262F] rounded-xl border border-[#2C2F3A] p-5">
        <h3 className="text-lg font-semibold text-[#F4F6F8] flex items-center gap-2">
          <Microscope className="w-5 h-5 text-[#10B981]" /> Cell Explorer
        </h3>
        <p className="text-xs text-[#8E92A4] mt-2">Click on any organelle to learn about its structure and function.</p>

        {active ? (
          <div className="mt-4 p-4 rounded-lg bg-[#181A20] border border-[#2C2F3A] animate-fade-in-up">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: active.color }} />
              <h4 className="text-sm font-semibold text-[#F4F6F8]">{active.name}</h4>
            </div>
            <p className="text-xs text-[#8E92A4] leading-relaxed">{active.desc}</p>
          </div>
        ) : (
          <div className="mt-4 space-y-2">
            {organelles.filter(o => !o.id.startsWith("ribosome2") && !o.id.startsWith("mitochondria2")).map((org) => (
              <button
                key={org.id}
                onClick={() => setActiveOrganelle(org.id)}
                className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-[#181A20] transition-all text-left"
              >
                <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: org.color }} />
                <span className="text-sm text-[#8E92A4] hover:text-[#F4F6F8]">{org.name}</span>
                <ChevronRight className="w-3 h-3 text-[#4D5060] ml-auto" />
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Chemistry: Periodic Table + Molecule Builder ───
function ChemistryLab() {
  const [selectedElement, setSelectedElement] = useState<any>(null);
  const [moleculeAtoms, setMoleculeAtoms] = useState<{ element: string; x: number; y: number; color: string }[]>([]);

  const elements = [
    { symbol: "H", name: "Hydrogen", number: 1, mass: "1.008", color: "#EF4444", category: "Nonmetal", desc: "The lightest and most abundant element in the universe. Forms water when combined with oxygen." },
    { symbol: "He", name: "Helium", number: 2, mass: "4.003", color: "#F59E0B", category: "Noble Gas", desc: "A colorless, odorless, tasteless noble gas. Used in balloons and as a cooling medium." },
    { symbol: "Li", name: "Lithium", number: 3, mass: "6.941", color: "#8B5CF6", category: "Alkali Metal", desc: "The lightest metal. Used in rechargeable batteries for electronics and electric vehicles." },
    { symbol: "C", name: "Carbon", number: 6, mass: "12.011", color: "#374151", category: "Nonmetal", desc: "The basis of organic chemistry. Forms diamonds, graphite, and the backbone of all living organisms." },
    { symbol: "N", name: "Nitrogen", number: 7, mass: "14.007", color: "#3B82F6", category: "Nonmetal", desc: "Makes up 78% of Earth's atmosphere. Essential for amino acids and DNA." },
    { symbol: "O", name: "Oxygen", number: 8, mass: "15.999", color: "#EF4444", category: "Nonmetal", desc: "Essential for respiration in most living organisms. Makes up 21% of Earth's atmosphere." },
    { symbol: "Na", name: "Sodium", number: 11, mass: "22.990", color: "#8B5CF6", category: "Alkali Metal", desc: "A highly reactive metal. Combines with chlorine to form table salt (NaCl)." },
    { symbol: "Mg", name: "Magnesium", number: 12, mass: "24.305", color: "#10B981", category: "Alkaline Earth", desc: "Essential for chlorophyll in plants. Burns with a bright white flame." },
    { symbol: "Al", name: "Aluminum", number: 13, mass: "26.982", color: "#6B7280", category: "Post-transition", desc: "Lightweight, corrosion-resistant metal. Most abundant metal in Earth's crust." },
    { symbol: "Si", name: "Silicon", number: 14, mass: "28.086", color: "#F59E0B", category: "Metalloid", desc: "The foundation of modern electronics. Second most abundant element in Earth's crust." },
    { symbol: "Cl", name: "Chlorine", number: 17, mass: "35.453", color: "#10B981", category: "Halogen", desc: "A yellow-green gas. Used for water purification and as a disinfectant." },
    { symbol: "Fe", name: "Iron", number: 26, mass: "55.845", color: "#F97316", category: "Transition Metal", desc: "Essential for hemoglobin in blood. The most widely used metal in industry." },
    { symbol: "Cu", name: "Copper", number: 29, mass: "63.546", color: "#F97316", category: "Transition Metal", desc: "Excellent conductor of electricity and heat. Used in wiring and plumbing." },
    { symbol: "Ag", name: "Silver", number: 47, mass: "107.87", color: "#9CA3AF", category: "Transition Metal", desc: "The best electrical conductor. Used in jewelry, electronics, and mirrors." },
    { symbol: "Au", name: "Gold", number: 79, mass: "196.97", color: "#F59E0B", category: "Transition Metal", desc: "Highly valued precious metal. Does not tarnish and is an excellent conductor." },
    { symbol: "U", name: "Uranium", number: 92, mass: "238.03", color: "#10B981", category: "Actinide", desc: "A heavy metal used as fuel in nuclear power plants and in nuclear weapons." },
  ];

  const addToMolecule = (el: any) => {
    const canvas = document.getElementById("molecule-canvas");
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    setMoleculeAtoms((prev) => [...prev, {
      element: el.symbol,
      x: 50 + Math.random() * (rect.width - 100),
      y: 50 + Math.random() * (rect.height - 100),
      color: el.color,
    }]);
  };

  return (
    <div className="flex flex-col lg:flex-row gap-4 h-full">
      <div className="flex-1 space-y-4 overflow-y-auto">
        {/* Periodic Table Grid */}
        <div className="bg-[#23262F] rounded-xl border border-[#2C2F3A] p-4">
          <h3 className="text-sm font-semibold text-[#F4F6F8] mb-3 flex items-center gap-2">
            <Beaker className="w-4 h-4 text-[#F59E0B]" /> Interactive Periodic Table
          </h3>
          <div className="grid grid-cols-8 gap-1.5">
            {elements.map((el) => (
              <button
                key={el.symbol}
                onClick={() => { setSelectedElement(el); addToMolecule(el); }}
                className={`aspect-square rounded-lg border transition-all hover:scale-110 flex flex-col items-center justify-center ${
                  selectedElement?.symbol === el.symbol
                    ? "border-[#F59E0B] ring-1 ring-[#F59E0B]/50"
                    : "border-[#2C2F3A] hover:border-[#F59E0B]/50"
                }`}
                style={{ backgroundColor: el.color + "20" }}
              >
                <span className="text-[8px] text-[#8E92A4] font-display">{el.number}</span>
                <span className="text-sm font-bold font-display" style={{ color: el.color }}>{el.symbol}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Molecule Builder Canvas */}
        <div className="bg-[#23262F] rounded-xl border border-[#2C2F3A] p-4">
          <h3 className="text-sm font-semibold text-[#F4F6F8] mb-3">Molecule Builder</h3>
          <div id="molecule-canvas" className="relative h-[200px] bg-[#0D0F17] rounded-lg overflow-hidden">
            {moleculeAtoms.length === 0 && (
              <div className="absolute inset-0 flex items-center justify-center text-[#4D5060] text-sm">
                Click elements above to build a molecule
              </div>
            )}
            {/* Bonds */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
              {moleculeAtoms.map((atom, i) => {
                if (i === 0) return null;
                const prev = moleculeAtoms[i - 1];
                return (
                  <line key={`bond-${i}`} x1={prev.x} y1={prev.y} x2={atom.x} y2={atom.y} stroke="#4D5060" strokeWidth="2" />
                );
              })}
            </svg>
            {/* Atoms */}
            {moleculeAtoms.map((atom, i) => (
              <div
                key={i}
                className="absolute w-10 h-10 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-lg animate-fade-in-up"
                style={{
                  left: atom.x - 20,
                  top: atom.y - 20,
                  backgroundColor: atom.color,
                  boxShadow: `0 0 15px ${atom.color}60`,
                }}
              >
                {atom.element}
              </div>
            ))}
          </div>
          {moleculeAtoms.length > 0 && (
            <button
              onClick={() => setMoleculeAtoms([])}
              className="mt-2 text-xs text-[#8E92A4] hover:text-[#F4F6F8] flex items-center gap-1 transition-colors"
            >
              <RotateCcw className="w-3 h-3" /> Clear molecule
            </button>
          )}
        </div>
      </div>

      {/* Element Detail Panel */}
      <div className="w-full lg:w-[300px] bg-[#23262F] rounded-xl border border-[#2C2F3A] p-5">
        <h3 className="text-lg font-semibold text-[#F4F6F8] flex items-center gap-2">
          <FlaskConical className="w-5 h-5 text-[#F59E0B]" /> Element Details
        </h3>
        {selectedElement ? (
          <div className="mt-4 animate-fade-in-up">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-16 h-16 rounded-xl flex flex-col items-center justify-center border-2" style={{ borderColor: selectedElement.color, backgroundColor: selectedElement.color + "20" }}>
                <span className="text-xs text-[#8E92A4]">{selectedElement.number}</span>
                <span className="text-2xl font-bold font-display" style={{ color: selectedElement.color }}>{selectedElement.symbol}</span>
              </div>
              <div>
                <h4 className="text-lg font-semibold text-[#F4F6F8]">{selectedElement.name}</h4>
                <p className="text-xs text-[#8E92A4]">{selectedElement.category}</p>
                <p className="text-sm font-display text-[#F4F6F8]">{selectedElement.mass} u</p>
              </div>
            </div>
            <p className="text-sm text-[#8E92A4] leading-relaxed">{selectedElement.desc}</p>
          </div>
        ) : (
          <div className="mt-8 text-center">
            <Atom className="w-12 h-12 text-[#4D5060] mx-auto mb-3" />
            <p className="text-sm text-[#8E92A4]">Select an element to view its properties</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Physics: Wave Simulator ───
function PhysicsLab() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [waveType, setWaveType] = useState<"sine" | "interference" | "standing">("sine");
  const [amplitude, setAmplitude] = useState(50);
  const [frequency, setFrequency] = useState(0.02);
  const [speed, setSpeed] = useState(0.05);
  const [isRunning, setIsRunning] = useState(true);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    let time = 0;

    const resize = () => {
      canvas.width = canvas.offsetWidth * window.devicePixelRatio;
      canvas.height = canvas.offsetHeight * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };
    resize();

    const animate = () => {
      if (isRunning) time += speed;
      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;

      ctx!.clearRect(0, 0, w, h);
      ctx!.fillStyle = "#0D0F17";
      ctx!.fillRect(0, 0, w, h);

      // Grid
      ctx!.strokeStyle = "#2C2F3A";
      ctx!.lineWidth = 0.5;
      for (let x = 0; x < w; x += 40) {
        ctx!.beginPath(); ctx!.moveTo(x, 0); ctx!.lineTo(x, h); ctx!.stroke();
      }
      for (let y = 0; y < h; y += 40) {
        ctx!.beginPath(); ctx!.moveTo(0, y); ctx!.lineTo(w, y); ctx!.stroke();
      }

      // Center line
      ctx!.strokeStyle = "#4D5060";
      ctx!.lineWidth = 0.5;
      ctx!.beginPath(); ctx!.moveTo(0, h / 2); ctx!.lineTo(w, h / 2); ctx!.stroke();

      // Wave
      ctx!.lineWidth = 2;

      if (waveType === "sine") {
        ctx!.strokeStyle = "#8B5CF6";
        ctx!.beginPath();
        for (let x = 0; x < w; x++) {
          const y = h / 2 + amplitude * Math.sin(frequency * x - time * 3);
          x === 0 ? ctx!.moveTo(x, y) : ctx!.lineTo(x, y);
        }
        ctx!.stroke();

        // Glow
        ctx!.strokeStyle = "#8B5CF640";
        ctx!.lineWidth = 8;
        ctx!.beginPath();
        for (let x = 0; x < w; x++) {
          const y = h / 2 + amplitude * Math.sin(frequency * x - time * 3);
          x === 0 ? ctx!.moveTo(x, y) : ctx!.lineTo(x, y);
        }
        ctx!.stroke();
      } else if (waveType === "interference") {
        // Two waves
        ctx!.strokeStyle = "#3B82F6";
        ctx!.beginPath();
        for (let x = 0; x < w; x++) {
          const y = h / 2 + amplitude * Math.sin(frequency * x - time * 3);
          x === 0 ? ctx!.moveTo(x, y) : ctx!.lineTo(x, y);
        }
        ctx!.stroke();

        ctx!.strokeStyle = "#F59E0B";
        ctx!.beginPath();
        for (let x = 0; x < w; x++) {
          const y = h / 2 + amplitude * 0.7 * Math.sin(frequency * 1.5 * x - time * 2.5 + 1);
          x === 0 ? ctx!.moveTo(x, y) : ctx!.lineTo(x, y);
        }
        ctx!.stroke();

        // Resultant
        ctx!.strokeStyle = "#10B981";
        ctx!.lineWidth = 2;
        ctx!.beginPath();
        for (let x = 0; x < w; x++) {
          const y = h / 2 + amplitude * Math.sin(frequency * x - time * 3) + amplitude * 0.7 * Math.sin(frequency * 1.5 * x - time * 2.5 + 1);
          x === 0 ? ctx!.moveTo(x, y) : ctx!.lineTo(x, y);
        }
        ctx!.stroke();
      } else {
        // Standing wave
        ctx!.strokeStyle = "#EC4899";
        ctx!.beginPath();
        for (let x = 0; x < w; x++) {
          const y = h / 2 + amplitude * Math.sin(frequency * x) * Math.cos(time * 3);
          x === 0 ? ctx!.moveTo(x, y) : ctx!.lineTo(x, y);
        }
        ctx!.stroke();
      }

      // Particles
      ctx!.fillStyle = "#F4F6F680";
      for (let x = 0; x < w; x += 20) {
        let y: number;
        if (waveType === "sine") {
          y = h / 2 + amplitude * Math.sin(frequency * x - time * 3);
        } else if (waveType === "interference") {
          y = h / 2 + amplitude * Math.sin(frequency * x - time * 3) + amplitude * 0.7 * Math.sin(frequency * 1.5 * x - time * 2.5 + 1);
        } else {
          y = h / 2 + amplitude * Math.sin(frequency * x) * Math.cos(time * 3);
        }
        ctx!.beginPath();
        ctx!.arc(x, y, 2, 0, Math.PI * 2);
        ctx!.fill();
      }

      animId = requestAnimationFrame(animate);
    };
    animate();

    return () => cancelAnimationFrame(animId);
  }, [waveType, amplitude, frequency, speed, isRunning]);

  return (
    <div className="flex flex-col lg:flex-row gap-4 h-full">
      <div className="flex-1 flex flex-col gap-4">
        <div className="flex-1 bg-[#0D0F17] rounded-xl border border-[#2C2F3A] overflow-hidden relative">
          <canvas ref={canvasRef} className="w-full h-full" />
          <div className="absolute top-3 left-3 px-3 py-1.5 rounded-lg bg-[#8B5CF6]/15 border border-[#8B5CF6]/30">
            <span className="text-[10px] uppercase tracking-wider text-[#8B5CF6] font-bold">Wave Physics Simulator</span>
          </div>
        </div>

        {/* Controls */}
        <div className="bg-[#23262F] rounded-xl border border-[#2C2F3A] p-4 space-y-3">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs text-[#8E92A4]">Wave Type:</span>
            {(["sine", "interference", "standing"] as const).map((type) => (
              <button
                key={type}
                onClick={() => setWaveType(type)}
                className={`px-3 py-1 rounded-lg text-xs font-medium capitalize transition-all ${
                  waveType === type
                    ? "bg-[#8B5CF6]/15 text-[#8B5CF6] border border-[#8B5CF6]/30"
                    : "bg-[#181A20] text-[#8E92A4] border border-[#2C2F3A]"
                }`}
              >
                {type}
              </button>
            ))}
            <button
              onClick={() => setIsRunning(!isRunning)}
              className="ml-auto w-8 h-8 rounded-lg bg-[#8B5CF6] flex items-center justify-center hover:bg-[#7C3AED] transition-all"
            >
              {isRunning ? <Pause className="w-4 h-4 text-white" /> : <Play className="w-4 h-4 text-white ml-0.5" />}
            </button>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="text-[10px] text-[#8E92A4] uppercase tracking-wider">Amplitude</label>
              <input type="range" min="10" max="100" value={amplitude} onChange={(e) => setAmplitude(Number(e.target.value))} className="w-full accent-[#8B5CF6]" />
            </div>
            <div>
              <label className="text-[10px] text-[#8E92A4] uppercase tracking-wider">Frequency</label>
              <input type="range" min="0.005" max="0.05" step="0.001" value={frequency} onChange={(e) => setFrequency(Number(e.target.value))} className="w-full accent-[#8B5CF6]" />
            </div>
            <div>
              <label className="text-[10px] text-[#8E92A4] uppercase tracking-wider">Speed</label>
              <input type="range" min="0.01" max="0.1" step="0.01" value={speed} onChange={(e) => setSpeed(Number(e.target.value))} className="w-full accent-[#8B5CF6]" />
            </div>
          </div>
        </div>
      </div>

      {/* Info Panel */}
      <div className="w-full lg:w-[280px] bg-[#23262F] rounded-xl border border-[#2C2F3A] p-5">
        <h3 className="text-lg font-semibold text-[#F4F6F8] flex items-center gap-2">
          <Waves className="w-5 h-5 text-[#8B5CF6]" /> Wave Properties
        </h3>
        <div className="mt-4 space-y-3">
          <div className="p-3 rounded-lg bg-[#181A20] border border-[#2C2F3A]">
            <h4 className="text-xs font-medium text-[#F4F6F8]">Amplitude (A)</h4>
            <p className="text-[11px] text-[#8E92A4] mt-1">Maximum displacement from equilibrium. Higher amplitude = more energy.</p>
          </div>
          <div className="p-3 rounded-lg bg-[#181A20] border border-[#2C2F3A]">
            <h4 className="text-xs font-medium text-[#F4F6F8]">Frequency (f)</h4>
            <p className="text-[11px] text-[#8E92A4] mt-1">Number of complete cycles per second. Measured in Hertz (Hz).</p>
          </div>
          <div className="p-3 rounded-lg bg-[#181A20] border border-[#2C2F3A]">
            <h4 className="text-xs font-medium text-[#F4F6F8]">Wavelength ({"\u03BB"})</h4>
            <p className="text-[11px] text-[#8E92A4] mt-1">Distance between two consecutive crests. v = f{"\u03BB"} where v is wave speed.</p>
          </div>
          <div className="p-3 rounded-lg bg-[#181A20] border border-[#2C2F3A]">
            <h4 className="text-xs font-medium text-[#F4F6F8]">Wave Equation</h4>
            <p className="text-[11px] text-[#8E92A4] mt-1 font-display">y(x,t) = A sin(kx - {"\u03C9"}t)</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Main STEM Lab Page ───
export default function StemLab() {
  const [activeTab, setActiveTab] = useState<LabTab>("biology");

  const tabs = [
    { id: "biology" as LabTab, label: "Biology", icon: Dna, color: "#10B981", desc: "Interactive Cell Explorer" },
    { id: "chemistry" as LabTab, label: "Chemistry", icon: FlaskConical, color: "#F59E0B", desc: "Periodic Table & Molecules" },
    { id: "physics" as LabTab, label: "Physics", icon: Atom, color: "#8B5CF6", desc: "Wave Simulator" },
  ];

  return (
    <div className="min-h-full px-4 lg:px-6 py-6 flex flex-col">
      {/* Header */}
      <div className="mb-4">
        <h1 className="text-2xl font-bold text-[#F4F6F8]">STEM Laboratory</h1>
        <p className="text-sm text-[#8E92A4] mt-1">Interactive science simulations for biology, chemistry, and physics</p>
      </div>

      {/* Tab Navigation */}
      <div className="flex items-center gap-2 mb-4">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                isActive
                  ? "text-white border"
                  : "bg-[#23262F] text-[#8E92A4] border border-[#2C2F3A] hover:text-[#F4F6F8]"
              }`}
              style={isActive ? { backgroundColor: tab.color + "20", borderColor: tab.color + "50", color: tab.color } : {}}
            >
              <tab.icon className="w-4 h-4" />
              <span className="hidden sm:inline">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Lab Content */}
      <div className="flex-1 min-h-[500px]">
        {activeTab === "biology" && <BiologyLab />}
        {activeTab === "chemistry" && <ChemistryLab />}
        {activeTab === "physics" && <PhysicsLab />}
      </div>
    </div>
  );
}
