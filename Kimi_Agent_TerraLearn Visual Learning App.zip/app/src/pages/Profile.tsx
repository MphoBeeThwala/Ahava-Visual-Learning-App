import { useState } from "react";
import { trpc } from "@/providers/trpc";
import {
  Award,
  BookOpen,
  Clock,
  Target,
  Flame,
  Star,
  TrendingUp,
  Bookmark,
  Zap,
  Brain,
  Mountain,
  Droplets,
  Sunrise,
} from "lucide-react";

const badges = [
  { id: 1, name: "First Safari", icon: Sunrise, color: "#F59E0B", earned: true, desc: "Complete Serengeti experience" },
  { id: 2, name: "Deep Sea Diver", icon: Droplets, color: "#3B82F6", earned: true, desc: "Complete Great Barrier Reef" },
  { id: 3, name: "Mountain Climber", icon: Mountain, color: "#8B5CF6", earned: false, desc: "Complete Everest experience" },
  { id: 4, name: "Historian", icon: BookOpen, color: "#10B981", earned: true, desc: "Complete 3 history experiences" },
  { id: 5, name: "Space Cadet", icon: Star, color: "#EC4899", earned: false, desc: "Complete ISS Tour" },
  { id: 6, name: "STEM Explorer", icon: Brain, color: "#06B6D4", earned: false, desc: "Complete all STEM labs" },
  { id: 7, name: "7-Day Streak", icon: Flame, color: "#EF4444", earned: true, desc: "Learn 7 days in a row" },
  { id: 8, name: "Quiz Master", icon: Zap, color: "#F97316", earned: false, desc: "Score 100% on 5 quizzes" },
];

export default function Profile() {
  const { data: stats } = trpc.progress.stats.useQuery(undefined, { retry: false });
  const { data: progress } = trpc.progress.list.useQuery(undefined, { retry: false });
  const [activeTab, setActiveTab] = useState<"progress" | "badges" | "bookmarks">("progress");

  const completionPercent = stats ? Math.round((stats.experiencesExplored / stats.totalExperiences) * 100) : 0;

  return (
    <div className="min-h-full px-4 lg:px-6 py-6">
      {/* Profile Header */}
      <div className="bg-gradient-to-r from-[#23262F] to-[#2C2F3A] rounded-2xl border border-[#2C2F3A] p-6 mb-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center text-2xl font-bold text-white">
            A
          </div>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-[#F4F6F8]">Alex Johnson</h1>
            <p className="text-sm text-[#8E92A4]">Grade 8 • Lincoln Middle School</p>
            <div className="flex items-center gap-3 mt-2">
              <span className="flex items-center gap-1 text-xs text-[#F59E0B]">
                <Flame className="w-3.5 h-3.5" /> 7-day streak
              </span>
              <span className="flex items-center gap-1 text-xs text-[#10B981]">
                <Award className="w-3.5 h-3.5" /> 3 badges
              </span>
            </div>
          </div>
          {/* Progress Ring */}
          <div className="relative w-20 h-20 shrink-0">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="42" fill="none" stroke="#2C2F3A" strokeWidth="8" />
              <circle
                cx="50" cy="50" r="42" fill="none" stroke="#3B82F6" strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={`${completionPercent * 2.64} 264`}
                className="transition-all duration-1000"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-lg font-bold text-[#F4F6F8] font-display">{completionPercent}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        {[
          { icon: BookOpen, label: "Completed", value: stats?.totalCompleted ?? 2, color: "#3B82F6" },
          { icon: Clock, label: "Time Spent", value: `${Math.floor((stats?.totalTimeSpent ?? 3900) / 3600)}h`, color: "#10B981" },
          { icon: Target, label: "Avg Score", value: `${stats?.avgScore ?? 87}%`, color: "#F59E0B" },
          { icon: TrendingUp, label: "In Progress", value: stats?.totalInProgress ?? 2, color: "#8B5CF6" },
        ].map((stat) => (
          <div key={stat.label} className="bg-[#23262F] rounded-xl p-3 border border-[#2C2F3A]">
            <div className="flex items-center gap-2 mb-1">
              <stat.icon className="w-4 h-4" style={{ color: stat.color }} />
              <span className="text-xs text-[#8E92A4]">{stat.label}</span>
            </div>
            <p className="text-xl font-bold text-[#F4F6F8] font-display">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-[#2C2F3A] mb-4">
        {(["progress", "badges", "bookmarks"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-3 text-sm font-medium capitalize border-b-2 transition-all ${
              activeTab === tab
                ? "border-[#3B82F6] text-[#3B82F6]"
                : "border-transparent text-[#8E92A4] hover:text-[#F4F6F8]"
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === "progress" && (
        <div className="space-y-3">
          {(progress ?? []).map((item: any) => (
            <div key={item.experienceId} className="bg-[#23262F] rounded-xl border border-[#2C2F3A] p-4 flex items-center gap-4">
              <img src={item.thumbnailUrl} alt={item.title} className="w-16 h-12 rounded-lg object-cover" />
              <div className="flex-1">
                <h3 className="text-sm font-medium text-[#F4F6F8]">{item.title}</h3>
                <div className="flex items-center gap-3 mt-1 text-xs text-[#8E92A4]">
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{Math.floor(item.timeSpentSeconds / 60)}m</span>
                  {item.quizScore && <span className="flex items-center gap-1"><Target className="w-3 h-3" />{item.quizScore}%</span>}
                  {item.completedAt && <span className="text-[#10B981]">Completed</span>}
                </div>
              </div>
              <div className="w-24">
                <div className="flex items-center justify-between text-[10px] text-[#8E92A4] mb-1">
                  <span>Progress</span>
                  <span>{item.completionPercentage}%</span>
                </div>
                <div className="h-1.5 bg-[#2C2F3A] rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-[#3B82F6] to-[#10B981] rounded-full transition-all" style={{ width: `${item.completionPercentage}%` }} />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === "badges" && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {badges.map((badge) => (
            <div
              key={badge.id}
              className={`p-4 rounded-xl border text-center transition-all ${
                badge.earned
                  ? "bg-[#23262F] border-[#2C2F3A]"
                  : "bg-[#181A20] border-[#2C2F3A] opacity-50"
              }`}
            >
              <div className="w-12 h-12 rounded-xl mx-auto mb-3 flex items-center justify-center" style={{ backgroundColor: badge.color + (badge.earned ? "20" : "10") }}>
                <badge.icon className="w-6 h-6" style={{ color: badge.earned ? badge.color : "#4D5060" }} />
              </div>
              <h3 className="text-sm font-medium text-[#F4F6F8]">{badge.name}</h3>
              <p className="text-[10px] text-[#8E92A4] mt-1">{badge.desc}</p>
            </div>
          ))}
        </div>
      )}

      {activeTab === "bookmarks" && (
        <div className="text-center py-12">
          <Bookmark className="w-12 h-12 text-[#4D5060] mx-auto mb-3" />
          <p className="text-sm text-[#8E92A4]">Bookmark experiences to save them for later</p>
        </div>
      )}
    </div>
  );
}
