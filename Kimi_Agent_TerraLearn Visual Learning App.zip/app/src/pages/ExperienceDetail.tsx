import { useParams, useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import {
  MapPin,
  Clock,
  Star,
  GraduationCap,
  Play,
  Bookmark,
  Share2,
  ChevronLeft,
  CheckCircle2,
  BookOpen,
  Target,
  Tag,
  Sparkles,
} from "lucide-react";
import { useState } from "react";

export default function ExperienceDetail() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { data: exp, isLoading } = trpc.experience.getBySlug.useQuery({ slug: slug! });
  const { data: hotspots } = trpc.hotspot.listByExperience.useQuery(
    { experienceId: exp?.id ?? 0 },
    { enabled: !!exp?.id }
  );
  const { data: quizzes } = trpc.quiz.listByExperience.useQuery(
    { experienceId: exp?.id ?? 0 },
    { enabled: !!exp?.id }
  );
  const [activeTab, setActiveTab] = useState<"overview" | "hotspots" | "quiz">("overview");

  if (isLoading) {
    return (
      <div className="min-h-full flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-2 border-[#3B82F6] border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!exp) {
    return (
      <div className="min-h-full flex flex-col items-center justify-center text-center px-6">
        <BookOpen className="w-16 h-16 text-[#4D5060] mb-4" />
        <h2 className="text-xl font-semibold text-[#F4F6F8]">Experience not found</h2>
        <p className="text-sm text-[#8E92A4] mt-2">The experience you're looking for doesn't exist.</p>
        <button
          onClick={() => navigate("/explore")}
          className="mt-4 px-4 py-2 rounded-lg bg-[#3B82F6] text-white text-sm font-medium hover:bg-[#2563EB] transition-all"
        >
          Browse Experiences
        </button>
      </div>
    );
  }

  const learningOutcomes = (exp.learningOutcomes as string[] | null) ?? [];
  const curriculumTags = (exp.curriculumTags as string[] | null) ?? [];
  const accessibilityFeatures = (exp.accessibilityFeatures as string[] | null) ?? [];

  return (
    <div className="min-h-full">
      {/* Hero */}
      <div className="relative h-[300px] lg:h-[400px] overflow-hidden">
        <img src={exp.thumbnailUrl} alt={exp.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#181A20] via-[#181A20]/40 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#181A20]/60 to-transparent" />

        <button
          onClick={() => navigate(-1)}
          className="absolute top-4 left-4 z-20 flex items-center gap-2 px-3 py-2 rounded-lg bg-[#181A20]/60 backdrop-blur-sm text-[#F4F6F8] text-sm hover:bg-[#181A20] transition-all"
        >
          <ChevronLeft className="w-4 h-4" /> Back
        </button>

        <div className="absolute bottom-0 left-0 right-0 p-6">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2 py-0.5 rounded-md bg-[#3B82F6]/20 text-[#3B82F6] text-[10px] font-bold uppercase tracking-wider">
              {exp.category}
            </span>
            {exp.isPremium && (
              <span className="px-2 py-0.5 rounded-md bg-[#F59E0B]/20 text-[#F59E0B] text-[10px] font-bold uppercase tracking-wider">
                Premium
              </span>
            )}
            {exp.stemType !== "none" && (
              <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                exp.stemType === "biology" ? "bg-[#10B981]/20 text-[#10B981]" :
                exp.stemType === "chemistry" ? "bg-[#F59E0B]/20 text-[#F59E0B]" :
                "bg-[#8B5CF6]/20 text-[#8B5CF6]"
              }`}>
              {exp.stemType}
            </span>
            )}
          </div>
          <h1 className="text-2xl lg:text-4xl font-bold text-[#F4F6F8]">{exp.title}</h1>
          <div className="flex items-center gap-4 mt-3 text-sm text-[#8E92A4]">
            {exp.country && (
              <span className="flex items-center gap-1"><MapPin className="w-4 h-4" />{exp.country}</span>
            )}
            <span className="flex items-center gap-1"><Clock className="w-4 h-4" />{Math.floor(exp.durationSeconds / 60)} minutes</span>
            <span className="flex items-center gap-1"><GraduationCap className="w-4 h-4" />Grades {exp.gradeLevelMin}-{exp.gradeLevelMax}</span>
            <span className="flex items-center gap-1"><Star className="w-4 h-4 text-[#F59E0B]" />{exp.avgRating} ({exp.reviewCount})</span>
          </div>
        </div>
      </div>

      {/* Action Bar */}
      <div className="px-6 py-4 border-b border-[#2C2F3A] flex items-center gap-3">
        <button
          onClick={() => navigate(`/viewer/${exp.slug}`)}
          className="flex items-center gap-2 px-6 py-3 rounded-xl bg-[#3B82F6] text-white font-medium hover:bg-[#2563EB] transition-all"
        >
          <Play className="w-4 h-4" /> Start Experience
        </button>
        <button className="flex items-center gap-2 px-4 py-3 rounded-xl bg-[#23262F] border border-[#2C2F3A] text-[#F4F6F8] text-sm hover:bg-[#2C2F3A] transition-all">
          <Bookmark className="w-4 h-4" /> Save
        </button>
        <button className="flex items-center gap-2 px-4 py-3 rounded-xl bg-[#23262F] border border-[#2C2F3A] text-[#F4F6F8] text-sm hover:bg-[#2C2F3A] transition-all">
          <Share2 className="w-4 h-4" /> Share
        </button>
      </div>

      {/* Tabs */}
      <div className="px-6 border-b border-[#2C2F3A] flex items-center gap-1">
        {(["overview", "hotspots", "quiz"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-3 text-sm font-medium capitalize border-b-2 transition-all ${
              activeTab === tab
                ? "border-[#3B82F6] text-[#3B82F6]"
                : "border-transparent text-[#8E92A4] hover:text-[#F4F6F8]"
            }`}
          >
            {tab}
            {tab === "hotspots" && hotspots && hotspots.length > 0 && (
              <span className="ml-1.5 text-[10px] bg-[#2C2F3A] px-1.5 py-0.5 rounded-full">{hotspots.length}</span>
            )}
            {tab === "quiz" && quizzes && quizzes.length > 0 && (
              <span className="ml-1.5 text-[10px] bg-[#2C2F3A] px-1.5 py-0.5 rounded-full">{quizzes.length}</span>
            )}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="px-6 py-6">
        {activeTab === "overview" && (
          <div className="space-y-6 max-w-3xl">
            <div>
              <h2 className="text-lg font-semibold text-[#F4F6F8] mb-2">About This Experience</h2>
              <p className="text-sm text-[#8E92A4] leading-relaxed">{exp.description}</p>
            </div>

            {learningOutcomes.length > 0 && (
              <div>
                <h3 className="text-sm font-medium text-[#F4F6F8] mb-3 flex items-center gap-2">
                  <Target className="w-4 h-4 text-[#10B981]" /> Learning Outcomes
                </h3>
                <div className="space-y-2">
                  {learningOutcomes.map((outcome: string, i: number) => (
                    <div key={i} className="flex items-start gap-2 text-sm text-[#8E92A4]">
                      <CheckCircle2 className="w-4 h-4 text-[#10B981] mt-0.5 shrink-0" />
                      {outcome}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {curriculumTags.length > 0 && (
              <div>
                <h3 className="text-sm font-medium text-[#F4F6F8] mb-3 flex items-center gap-2">
                  <Tag className="w-4 h-4 text-[#3B82F6]" /> Curriculum Tags
                </h3>
                <div className="flex flex-wrap gap-2">
                  {curriculumTags.map((tag: string) => (
                    <span key={tag} className="px-3 py-1 rounded-lg bg-[#23262F] border border-[#2C2F3A] text-xs text-[#8E92A4]">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {accessibilityFeatures.length > 0 && (
              <div>
                <h3 className="text-sm font-medium text-[#F4F6F8] mb-3 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#8B5CF6]" /> Accessibility
                </h3>
                <div className="flex flex-wrap gap-2">
                  {accessibilityFeatures.map((feat: string) => (
                    <span key={feat} className="px-3 py-1 rounded-lg bg-[#8B5CF6]/10 border border-[#8B5CF6]/20 text-xs text-[#8B5CF6]">
                      {feat}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === "hotspots" && (
          <div className="space-y-3">
            {hotspots && hotspots.length > 0 ? (
              hotspots.map((hs: any) => (
                <div key={hs.id} className="p-4 rounded-xl bg-[#23262F] border border-[#2C2F3A]">
                  <div className="flex items-start gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      hs.iconType === "quiz" ? "bg-[#F59E0B]/15" : "bg-[#3B82F6]/15"
                    }`}>
                      {hs.iconType === "quiz" ? (
                        <Target className="w-4 h-4 text-[#F59E0B]" />
                      ) : (
                        <Sparkles className="w-4 h-4 text-[#3B82F6]" />
                      )}
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-[#F4F6F8]">{hs.title}</h3>
                      <p className="text-xs text-[#8E92A4] mt-1">{hs.description}</p>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12">
                <Sparkles className="w-12 h-12 text-[#4D5060] mx-auto mb-3" />
                <p className="text-sm text-[#8E92A4]">No hotspots available for this experience yet.</p>
              </div>
            )}
          </div>
        )}

        {activeTab === "quiz" && (
          <div className="space-y-4 max-w-2xl">
            {quizzes && quizzes.length > 0 ? (
              quizzes.map((quiz: any, idx: number) => (
                <div key={quiz.id} className="p-5 rounded-xl bg-[#23262F] border border-[#2C2F3A]">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="w-6 h-6 rounded-full bg-[#3B82F6]/15 text-[#3B82F6] text-xs font-bold flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <span className="text-[10px] uppercase tracking-wider text-[#F59E0B] font-medium">{quiz.points} pts</span>
                  </div>
                  <p className="text-sm text-[#F4F6F8] font-medium mb-4">{quiz.question}</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {quiz.options.map((opt: string, i: number) => (
                      <button
                        key={i}
                        className="p-3 rounded-lg bg-[#181A20] border border-[#2C2F3A] text-sm text-[#8E92A4] hover:border-[#3B82F6]/50 hover:text-[#F4F6F8] transition-all text-left"
                      >
                        <span className="text-[#4D5060] mr-2">{String.fromCharCode(65 + i)}.</span>
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12">
                <Target className="w-12 h-12 text-[#4D5060] mx-auto mb-3" />
                <p className="text-sm text-[#8E92A4]">No quizzes available for this experience yet.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
