import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";

export const classRouter = createRouter({
  create: authedQuery
    .input(z.object({ name: z.string(), gradeLevel: z.number(), subject: z.string() }))
    .mutation(async ({ input }) => {
      const inviteCode = Math.random().toString(36).substring(2, 8).toUpperCase();
      return { id: 1, ...input, inviteCode, createdAt: new Date() };
    }),

  list: authedQuery.query(async () => {
    return [
      { id: 1, name: "Grade 8 Biology", gradeLevel: 8, subject: "Biology", inviteCode: "BIO8X2", studentCount: 24, createdAt: new Date("2024-01-15") },
      { id: 2, name: "Grade 10 Physics", gradeLevel: 10, subject: "Physics", inviteCode: "PHY10A", studentCount: 18, createdAt: new Date("2024-02-01") },
      { id: 3, name: "Grade 6 Earth Science", gradeLevel: 6, subject: "Earth Science", inviteCode: "ES6B3", studentCount: 30, createdAt: new Date("2024-03-10") },
    ];
  }),

  getById: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return {
        id: input.id,
        name: "Grade 8 Biology",
        gradeLevel: 8,
        subject: "Biology",
        inviteCode: "BIO8X2",
        students: [
          { id: 1, name: "Alex Johnson", progress: 85, lastActive: "2 hours ago" },
          { id: 2, name: "Maria Garcia", progress: 92, lastActive: "1 hour ago" },
          { id: 3, name: "Sam Chen", progress: 67, lastActive: "5 hours ago" },
          { id: 4, name: "Emma Wilson", progress: 100, lastActive: "30 minutes ago" },
          { id: 5, name: "Liam Brown", progress: 45, lastActive: "1 day ago" },
        ],
        assignments: [
          { id: 1, experienceTitle: "Serengeti Great Migration", dueDate: "2024-06-30", status: "active" },
          { id: 2, experienceTitle: "Great Barrier Reef Dive", dueDate: "2024-07-15", status: "active" },
          { id: 3, experienceTitle: "Amazon Rainforest Canopy", dueDate: "2024-07-01", status: "completed" },
        ],
      };
    }),

  join: authedQuery
    .input(z.object({ inviteCode: z.string() }))
    .mutation(async () => {
      return { success: true, classId: 1, message: "Joined class successfully" };
    }),
});
