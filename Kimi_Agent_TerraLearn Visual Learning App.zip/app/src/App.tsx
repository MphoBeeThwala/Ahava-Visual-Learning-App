import { Routes, Route } from "react-router";
import { AppLayout } from "./components/AppLayout";
import Home from "./pages/Home";
import Explore from "./pages/Explore";
import ExperienceDetail from "./pages/ExperienceDetail";
import Viewer360 from "./pages/Viewer360";
import StemLab from "./pages/StemLab";
import TeacherDashboard from "./pages/TeacherDashboard";
import Profile from "./pages/Profile";
import Tourism from "./pages/Tourism";
import Contribute from "./pages/Contribute";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="*"
        element={
          <AppLayout>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/explore" element={<Explore />} />
              <Route path="/experience/:slug" element={<ExperienceDetail />} />
              <Route path="/viewer/:slug" element={<Viewer360 />} />
              <Route path="/lab" element={<StemLab />} />
              <Route path="/teacher" element={<TeacherDashboard />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/tourism" element={<Tourism />} />
              <Route path="/contribute" element={<Contribute />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </AppLayout>
        }
      />
    </Routes>
  );
}
