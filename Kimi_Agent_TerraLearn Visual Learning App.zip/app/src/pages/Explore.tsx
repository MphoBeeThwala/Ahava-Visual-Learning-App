import { useState } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import {
  Search,
  MapPin,
  Clock,
  Star,
  Bookmark,
  GraduationCap,
  X,
  SlidersHorizontal,
} from "lucide-react";

const categoryTabs = [
  { value: "", label: "All" },
  { value: "nature", label: "Nature" },
  { value: "history", label: "History" },
  { value: "stem", label: "STEM" },
  { value: "culture", label: "Culture" },
  { value: "conservation", label: "Conservation" },
];

const subcategoryChips = [
  "Wildlife", "Geology", "Marine", "Ancient Civilizations", "Rainforest",
  "Climate Science", "Waterfalls", "Mountains", "Desert", "Geothermal",
  "Ancient Cities", "Temples", "Ancient Rome", "Architecture", "Astronomy",
  "Cell Biology", "Chemistry", "Physics", "Space",
];

export default function Explore() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [selectedSubs, setSelectedSubs] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [gradeLevel, setGradeLevel] = useState<number | undefined>();

  const { data: experiences, isLoading } = trpc.experience.list.useQuery({
    category: category || undefined,
    search: search || undefined,
    gradeLevel,
    limit: 50,
  });

  const toggleSub = (sub: string) => {
    setSelectedSubs((prev) =>
      prev.includes(sub) ? prev.filter((s) => s !== sub) : [...prev, sub]
    );
  };

  const filtered = (experiences ?? []).filter((exp: any) => {
    if (selectedSubs.length === 0) return true;
    return selectedSubs.includes(exp.subcategory);
  });

  return (
    <div className="min-h-full px-4 lg:px-6 py-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-[#F4F6F8]">Explore Experiences</h1>
        <p className="text-sm text-[#8E92A4] mt-1">Browse 2,400+ immersive field trips and STEM labs</p>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex items-center gap-3 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8E92A4]" />
          <input
            type="text"
            placeholder="Search experiences, countries, topics..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#23262F] border border-[#2C2F3A] text-sm text-[#F4F6F8] placeholder:text-[#4D5060] focus:outline-none focus:border-[#3B82F6] transition-colors"
          />
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className={`p-2.5 rounded-xl border transition-all ${showFilters ? "bg-[#3B82F6]/15 border-[#3B82F6]/50 text-[#3B82F6]" : "bg-[#23262F] border-[#2C2F3A] text-[#8E92A4] hover:text-[#F4F6F8]"}`}
        >
          <SlidersHorizontal className="w-4 h-4" />
        </button>
      </div>

      {/* Filter Panel */}
      {showFilters && (
        <div className="mb-6 p-4 rounded-xl bg-[#23262F] border border-[#2C2F3A] animate-fade-in-up">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium text-[#F4F6F8]">Filters</h3>
            <button onClick={() => setShowFilters(false)} className="text-[#8E92A4] hover:text-[#F4F6F8]">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs text-[#8E92A4]">Grade:</span>
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((g) => (
              <button
                key={g}
                onClick={() => setGradeLevel(gradeLevel === g ? undefined : g)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                  gradeLevel === g
                    ? "bg-[#3B82F6] text-white"
                    : "bg-[#2C2F3A] text-[#8E92A4] hover:text-[#F4F6F8]"
                }`}
              >
                {g}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Category Tabs */}
      <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-2 scrollbar-none">
        {categoryTabs.map((tab) => (
          <button
            key={tab.value}
            onClick={() => setCategory(tab.value)}
            className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
              category === tab.value
                ? "bg-[#3B82F6]/15 text-[#3B82F6] border border-[#3B82F6]/30"
                : "bg-[#23262F] text-[#8E92A4] border border-[#2C2F3A] hover:text-[#F4F6F8] hover:border-[#4D5060]"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Subcategory Chips */}
      <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2 scrollbar-none">
        {subcategoryChips.map((sub) => (
          <button
            key={sub}
            onClick={() => toggleSub(sub)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
              selectedSubs.includes(sub)
                ? "bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30"
                : "bg-[#23262F] text-[#8E92A4] border border-[#2C2F3A] hover:border-[#4D5060]"
            }`}
          >
            {sub}
          </button>
        ))}
      </div>

      {/* Results Count */}
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-[#8E92A4]">
          {filtered.length} experience{filtered.length !== 1 ? "s" : ""} found
        </p>
      </div>

      {/* Experience Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="rounded-xl bg-[#23262F] border border-[#2C2F3A] overflow-hidden animate-pulse">
              <div className="aspect-video bg-[#2C2F3A]" />
              <div className="p-4 space-y-2">
                <div className="h-4 bg-[#2C2F3A] rounded w-3/4" />
                <div className="h-3 bg-[#2C2F3A] rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <Search className="w-12 h-12 text-[#4D5060] mx-auto mb-4" />
          <h3 className="text-lg font-medium text-[#F4F6F8]">No experiences found</h3>
          <p className="text-sm text-[#8E92A4] mt-1">Try adjusting your filters or search terms</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((exp: any) => (
            <Link
              key={exp.id}
              to={`/experience/${exp.slug}`}
              className="group bg-[#23262F] rounded-xl border border-[#2C2F3A] overflow-hidden hover:border-[#3B82F6]/50 transition-all duration-300 hover:shadow-lg hover:shadow-[#3B82F6]/5"
            >
              <div className="aspect-video overflow-hidden relative">
                <img
                  src={exp.thumbnailUrl}
                  alt={exp.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#181A20]/80 via-transparent to-transparent" />
                <div className="absolute top-3 right-3 flex items-center gap-2">
                  {exp.isPremium && (
                    <span className="px-2 py-0.5 rounded-md bg-[#F59E0B]/90 text-[#181A20] text-[10px] font-bold uppercase tracking-wider">
                      Premium
                    </span>
                  )}
                  <button className="w-7 h-7 rounded-full bg-[#181A20]/60 backdrop-blur-sm flex items-center justify-center hover:bg-[#181A20] transition-colors">
                    <Bookmark className="w-3.5 h-3.5 text-[#F4F6F8]" />
                  </button>
                </div>
                {exp.stemType !== "none" && (
                  <div className="absolute top-3 left-3">
                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                      exp.stemType === "biology" ? "bg-[#10B981]/90 text-white" :
                      exp.stemType === "chemistry" ? "bg-[#F59E0B]/90 text-[#181A20]" :
                      "bg-[#8B5CF6]/90 text-white"
                    }`}>
                      {exp.stemType}
                    </span>
                  </div>
                )}
              </div>
              <div className="p-4">
                <span className="text-[10px] uppercase tracking-wider text-[#3B82F6] font-medium">{exp.category}</span>
                <h3 className="text-sm font-semibold text-[#F4F6F8] mt-1 group-hover:text-[#3B82F6] transition-colors line-clamp-1">
                  {exp.title}
                </h3>
                <p className="text-xs text-[#8E92A4] mt-1 line-clamp-2">{exp.description}</p>
                <div className="flex items-center gap-3 mt-3 text-xs text-[#8E92A4]">
                  {exp.country && (
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3" />{exp.country}
                    </span>
                  )}
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />{Math.floor(exp.durationSeconds / 60)}m
                  </span>
                  <span className="flex items-center gap-1">
                    <Star className="w-3 h-3 text-[#F59E0B]" />{exp.avgRating}
                  </span>
                  <span className="flex items-center gap-1">
                    <GraduationCap className="w-3 h-3" />Gr {exp.gradeLevelMin}-{exp.gradeLevelMax}
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
