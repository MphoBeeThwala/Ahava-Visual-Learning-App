import { useState } from "react";
import { trpc } from "@/providers/trpc";
import {
  Users,
  BookOpen,
  TrendingUp,
  GraduationCap,
  Plus,
  ChevronRight,
  Clock,
  Target,
  BarChart3,
  ClipboardList,
} from "lucide-react";

export default function TeacherDashboard() {
  const { data: classes } = trpc.class.list.useQuery(undefined, { retry: false });
  const [selectedClass, setSelectedClass] = useState<number | null>(null);
  const { data: classDetail } = trpc.class.getById.useQuery(
    { id: selectedClass ?? 1 },
    { enabled: !!selectedClass }
  );

  const stats = [
    { icon: Users, label: "Total Students", value: "72", color: "#3B82F6", change: "+5 this month" },
    { icon: BookOpen, label: "Active Classes", value: "3", color: "#10B981", change: "All active" },
    { icon: Target, label: "Assignments", value: "12", color: "#F59E0B", change: "4 due this week" },
    { icon: TrendingUp, label: "Avg Completion", value: "78%", color: "#8B5CF6", change: "+3% vs last month" },
  ];

  return (
    <div className="min-h-full px-4 lg:px-6 py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-[#F4F6F8]">Teacher Dashboard</h1>
          <p className="text-sm text-[#8E92A4] mt-1">Manage classes, assignments, and student progress</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#3B82F6] text-white text-sm font-medium hover:bg-[#2563EB] transition-all">
          <Plus className="w-4 h-4" /> New Class
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-[#23262F] rounded-xl p-4 border border-[#2C2F3A]">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: stat.color + "20" }}>
                <stat.icon className="w-4 h-4" style={{ color: stat.color }} />
              </div>
            </div>
            <p className="text-2xl font-bold text-[#F4F6F8] font-display">{stat.value}</p>
            <p className="text-xs text-[#8E92A4] mt-0.5">{stat.label}</p>
            <p className="text-[10px] text-[#10B981] mt-1">{stat.change}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Classes List */}
        <div className="lg:col-span-1">
          <h2 className="text-sm font-semibold text-[#F4F6F8] mb-3 flex items-center gap-2">
            <GraduationCap className="w-4 h-4 text-[#3B82F6]" /> My Classes
          </h2>
          <div className="space-y-2">
            {(classes ?? []).map((cls: any) => (
              <button
                key={cls.id}
                onClick={() => setSelectedClass(cls.id)}
                className={`w-full text-left p-4 rounded-xl border transition-all ${
                  selectedClass === cls.id
                    ? "bg-[#3B82F6]/10 border-[#3B82F6]/30"
                    : "bg-[#23262F] border-[#2C2F3A] hover:border-[#4D5060]"
                }`}
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium text-[#F4F6F8]">{cls.name}</h3>
                  <ChevronRight className="w-4 h-4 text-[#4D5060]" />
                </div>
                <div className="flex items-center gap-3 mt-2 text-xs text-[#8E92A4]">
                  <span>Grade {cls.gradeLevel}</span>
                  <span>{cls.studentCount} students</span>
                  <span>Code: <span className="text-[#3B82F6] font-mono">{cls.inviteCode}</span></span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Class Detail */}
        <div className="lg:col-span-2">
          {classDetail ? (
            <div className="space-y-4">
              {/* Students */}
              <div className="bg-[#23262F] rounded-xl border border-[#2C2F3A] p-4">
                <h3 className="text-sm font-semibold text-[#F4F6F8] mb-3 flex items-center gap-2">
                  <Users className="w-4 h-4 text-[#10B981]" /> Students
                </h3>
                <div className="space-y-2">
                  {classDetail.students.map((student: any) => (
                    <div key={student.id} className="flex items-center gap-3 p-2.5 rounded-lg bg-[#181A20]">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center text-xs font-bold text-white">
                        {student.name.charAt(0)}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-[#F4F6F8]">{student.name}</p>
                        <p className="text-[10px] text-[#8E92A4]">{student.lastActive}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-1.5 bg-[#2C2F3A] rounded-full overflow-hidden">
                          <div className="h-full bg-gradient-to-r from-[#3B82F6] to-[#10B981] rounded-full" style={{ width: `${student.progress}%` }} />
                        </div>
                        <span className="text-xs text-[#8E92A4] font-display w-8">{student.progress}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Assignments */}
              <div className="bg-[#23262F] rounded-xl border border-[#2C2F3A] p-4">
                <h3 className="text-sm font-semibold text-[#F4F6F8] mb-3 flex items-center gap-2">
                  <ClipboardList className="w-4 h-4 text-[#F59E0B]" /> Assignments
                </h3>
                <div className="space-y-2">
                  {classDetail.assignments.map((assign: any) => (
                    <div key={assign.id} className="flex items-center justify-between p-3 rounded-lg bg-[#181A20]">
                      <div>
                        <p className="text-sm text-[#F4F6F8]">{assign.experienceTitle}</p>
                        <p className="text-[10px] text-[#8E92A4] flex items-center gap-1 mt-0.5">
                          <Clock className="w-3 h-3" /> Due {assign.dueDate}
                        </p>
                      </div>
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-medium ${
                        assign.status === "completed" ? "bg-[#10B981]/15 text-[#10B981]" : "bg-[#3B82F6]/15 text-[#3B82F6]"
                      }`}>
                        {assign.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-[#23262F] rounded-xl border border-[#2C2F3A] p-8 text-center">
              <BarChart3 className="w-12 h-12 text-[#4D5060] mx-auto mb-3" />
              <p className="text-sm text-[#8E92A4]">Select a class to view details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
