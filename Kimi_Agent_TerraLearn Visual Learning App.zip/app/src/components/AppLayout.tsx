import { Link, useLocation } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import {
  Globe,
  FlaskConical,
  LayoutDashboard,
  Users,
  Compass,
  Crown,
  Upload,
  LogOut,
  LogIn,
  Menu,
  X,
} from "lucide-react";
import { useState } from "react";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/" },
  { icon: Globe, label: "Field Trips", path: "/explore" },
  { icon: FlaskConical, label: "STEM Lab", path: "/lab" },
  { icon: Users, label: "Teacher Hub", path: "/teacher" },
  { icon: Compass, label: "My Progress", path: "/profile" },
  { icon: Crown, label: "Tourism", path: "/tourism" },
  { icon: Upload, label: "Contribute", path: "/contribute" },
];

export function AppLayout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#181A20]">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed lg:static inset-y-0 left-0 z-50 w-[250px] bg-[#23262F] flex flex-col transition-transform duration-300 ${
          mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        }`}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-6 py-5 border-b border-[#2C2F3A]">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#3B82F6] to-[#10B981] flex items-center justify-center">
            <Globe className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-[#F4F6F8] leading-tight">TerraLearn</h1>
            <p className="text-[10px] text-[#8E92A4] uppercase tracking-wider">Explore & Learn</p>
          </div>
          <button
            className="ml-auto lg:hidden text-[#8E92A4]"
            onClick={() => setMobileOpen(false)}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Nav items */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setMobileOpen(false)}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                  isActive
                    ? "bg-[#3B82F6]/15 text-[#3B82F6]"
                    : "text-[#8E92A4] hover:text-[#F4F6F8] hover:bg-[#2C2F3A]"
                }`}
              >
                <item.icon className={`w-[18px] h-[18px] ${isActive ? "text-[#3B82F6]" : ""}`} />
                {item.label}
              </Link>
            );
          })}
        </nav>

        {/* User section */}
        <div className="px-3 py-4 border-t border-[#2C2F3A]">
          {isAuthenticated ? (
            <div className="space-y-2">
              <div className="flex items-center gap-3 px-4 py-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center text-xs font-bold text-white">
                  {user?.name?.charAt(0) || "U"}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[#F4F6F8] truncate">{user?.name || "User"}</p>
                  <p className="text-xs text-[#8E92A4] capitalize">{user?.role || "Student"}</p>
                </div>
              </div>
              <button
                onClick={logout}
                className="flex items-center gap-3 px-4 py-2 w-full text-sm text-[#8E92A4] hover:text-[#F4F6F8] hover:bg-[#2C2F3A] rounded-xl transition-all"
              >
                <LogOut className="w-[18px] h-[18px]" />
                Sign Out
              </button>
            </div>
          ) : (
            <Link
              to="/login"
              className="flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-[#8E92A4] hover:text-[#F4F6F8] hover:bg-[#2C2F3A] rounded-xl transition-all"
            >
              <LogIn className="w-[18px] h-[18px]" />
              Sign In
            </Link>
          )}
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top header */}
        <header className="h-[60px] flex items-center justify-between px-4 lg:px-6 border-b border-[#2C2F3A] bg-[#181A20]/80 backdrop-blur-md z-30">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileOpen(true)}
              className="lg:hidden p-2 rounded-lg text-[#8E92A4] hover:text-[#F4F6F8] hover:bg-[#2C2F3A] transition-all"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>

          <div className="flex items-center gap-3">
            <Link
              to="/explore"
              className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-lg bg-[#3B82F6] text-white text-sm font-medium hover:bg-[#2563EB] transition-all"
            >
              <Compass className="w-4 h-4" />
              Start Exploring
            </Link>
          </div>
        </header>

        {/* Page content */}
        <div className="flex-1 overflow-y-auto">
          {children}
        </div>
      </main>
    </div>
  );
}
